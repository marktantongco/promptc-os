import { useState, useCallback } from "react";

const FONT_CSS=`@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Mono:wght@400;500&family=DM+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap');
*{box-sizing:border-box;margin:0;padding:0}html{scroll-behavior:smooth;-webkit-text-size-adjust:100%}
body{font-family:'DM Sans',system-ui,sans-serif;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}
::-webkit-scrollbar{width:5px;height:5px}::-webkit-scrollbar-track{background:#0B0D10}::-webkit-scrollbar-thumb{background:#ffffff18;border-radius:3px}::-webkit-scrollbar-thumb:hover{background:#ffffff30}
@keyframes fadeSlide{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
@keyframes popIn{from{opacity:0;transform:scale(0.94)}to{opacity:1;transform:scale(1)}}
@keyframes shimmerIn{from{opacity:0;transform:translateX(-8px)}to{opacity:1;transform:none}}
@keyframes zoneEnter{from{opacity:0;transform:translateY(8px) scale(0.99)}to{opacity:1;transform:none}}
@keyframes ripple{0%{transform:scale(0);opacity:0.5}100%{transform:scale(3);opacity:0}}
@keyframes copyFlash{0%{background:#22c55e30}50%{background:#22c55e15}100%{background:transparent}}
@keyframes glowPulse{0%,100%{opacity:1}50%{opacity:0.7}}
.anim-zone{animation:zoneEnter 0.3s cubic-bezier(0.16,1,0.3,1)}
.anim-pop{animation:popIn 0.2s cubic-bezier(0.16,1,0.3,1)}
.anim-slide{animation:fadeSlide 0.25s cubic-bezier(0.16,1,0.3,1)}
.anim-shimmer{animation:shimmerIn 0.2s cubic-bezier(0.16,1,0.3,1)}
button:active{transform:scale(0.96)!important}
`;

function fallbackCopy(text){const el=document.createElement("textarea");el.value=text;el.style.cssText="position:fixed;top:-9999px;opacity:0";document.body.appendChild(el);el.focus();el.select();try{document.execCommand("copy");}catch(e){}document.body.removeChild(el);}
function useCopy(){return useCallback((text)=>{if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(text).catch(()=>fallbackCopy(text));}else{fallbackCopy(text);}},[]); }

const C = {
  bg:"#0B0D10", sur:"#14161A", bdr:"#ffffff12", bdrH:"#ffffff25",
  tx:"#FFFFFF", mu:"#a1a1aa", di:"#6b7280", fa:"#4b5563",
  cy:"#4DFFFF", vi:"#FF6B00", mg:"#FF4FD8", am:"#FFB000",
  gn:"#22c55e", bl:"#38bdf8", or:"#f97316", rd:"#ef4444",
  mn:"'DM Mono','JetBrains Mono',monospace",
  ss:"'DM Sans',system-ui,sans-serif",
  hd:"'Bebas Neue',sans-serif",
};
const ZC={activate:C.cy,build:C.vi,validate:C.gn,playbook:C.am,builder:C.mg};
const AC={Eagle:C.am,Beaver:C.vi,Ant:C.mg,Owl:C.cy,Rabbit:C.gn,Dolphin:C.bl,Elephant:C.or};
const AE={Eagle:"🦅",Beaver:"🦫",Ant:"🐜",Owl:"🦉",Rabbit:"🐇",Dolphin:"🐬",Elephant:"🐘"};

const ZONES=[
  {id:"activate",label:"⚡ ACTIVATE",sub:"Copy-paste to AI. Start fast."},
  {id:"build",   label:"🏗 BUILD",   sub:"Reference library. All frameworks."},
  {id:"validate",label:"✅ VALIDATE",sub:"Score, lint, refine."},
  {id:"playbook",label:"📋 PLAYBOOK",sub:"18 workflows. Step-by-step."},
  {id:"builder", label:"🔨 BUILDER", sub:"Interactive prompt composers."},
];

const MASTER=`You are my expert AI assistant, business partner, and creative strategist.
Your job is to always act in MY best interest — not just answer questions,
but proactively identify what I actually need versus what I literally asked.

Rules you must always follow:
1. Be direct — no filler, no fluff, no unnecessary disclaimers.
2. When I ask for code, give WORKING code. Not pseudocode or examples.
3. When I ask for ideas, give me ranked, actionable options — not just lists.
4. Always tell me if there's a better or faster way to do what I'm asking.
5. Default to expert-level responses unless I say otherwise.
6. If my request is vague, make a smart assumption, state it, then proceed.
7. If something I want is risky or suboptimal, flag it, then do it anyway unless I say stop.
8. Remember context within this conversation — never ask me to repeat myself.
9. Format your replies for scanability: use headers, bullets, and bold for key points.
10. Always end complex answers with a "⚡ Recommended Next Step".`;

const ADVOCATE=`For this entire conversation, I want you to be my advocate, not just my assistant.
That means:
- If I'm about to make a mistake, warn me.
- If there's a better approach, tell me even if I didn't ask.
- Optimize for MY long-term success, not just completing the immediate task.
- If something I ask for could hurt my project, business, or goals, flag it.
- Prioritize quality over speed unless I say otherwise.
- I give you permission to push back on my ideas if you have a good reason.`;

const MODS=[
  ["act as an expert in [field]","Forces deep, authoritative responses"],
  ["give me the version a senior dev would write","Skips beginner-level output"],
  ["don't explain, just do it","Removes verbose preambles"],
  ["think step by step before answering","Triggers deeper reasoning chain"],
  ["what would you do if this was your own business?","Gets honest, opinionated advice"],
  ["what am I missing or not asking that I should be?","Surfaces blind spots"],
  ["give me the 80/20 version","Highest impact, minimum complexity"],
  ["assume I'm an expert, skip the basics","Removes redundant context"],
  ["be brutally honest","Removes diplomatic softening"],
  ["rank these by impact","Forces prioritization, not listing"],
];

const TASKS=[
  {label:"🎬 YouTube",content:`Act as a YouTube growth strategist with 10 years of experience.
When I give you a topic, automatically:
1. Identify the 3 best angles for that niche
2. Generate a scroll-stopping title using proven CTR patterns
3. Write a structured script with hook, body, and CTA
4. Suggest 5 SEO-optimized tags

Topic: [your topic here]`},
  {label:"💻 Coding",content:`You are a senior software engineer and architect.
When I describe a feature, always:
- Ask clarifying questions ONLY if something is truly ambiguous
- Write production-ready code, not demo code
- Add error handling automatically
- Explain the "why" behind any non-obvious decision in a single comment
- Flag performance or security concerns before I ask`},
  {label:"📊 Business",content:`Act as my COO and strategist. When I describe a problem or goal:
- Identify the fastest path to results (the 80/20 solution)
- Separate what I MUST do from what is optional
- Give me a prioritized action plan, not just advice
- Tell me what successful people in this space actually do, not just theory`},
  {label:"🔍 Research",content:`You are a research assistant. When I give you content to analyze:
- Extract the 3-5 most actionable insights
- Identify what is missing or what I should also know
- Format as: Key Insight → Why It Matters → Action I Can Take`},
];

const TMPLS=[
  {label:"🌐 Web App",desc:"Next.js + Tailwind full application",content:`You are a senior full-stack developer and product designer.

ROLE: Senior full-stack developer + product designer
GOAL: [Describe your app in one sentence]

FUNCTIONAL REQUIREMENTS
- Dynamic UI components
- Mobile-first responsive layout
- Interactive sections with user feedback
- Modular, reusable component architecture

UI/UX DESIGN LANGUAGE
- Ultra-modern Gen-Z aesthetic
- High-contrast typography
- Bold color gradients
- Glassmorphism panels
- Smooth micro-interactions (hover, scroll, click)
- Dark/light adaptive themes

TECHNICAL STACK
- Framework: Next.js (App Router)
- Styling: Tailwind CSS
- Animation: Framer Motion or GSAP
- Components: shadcn/ui
- Accessible semantic HTML

OUTPUT FORMAT
Generate:
1. Project folder structure
2. Full source code (all files)
3. Instructions to run locally
4. Key component explanations

CONSTRAINTS
- Mobile-first always
- WCAG AA accessibility minimum
- 60fps animation budget
- No placeholder lorem ipsum content
- Avoid SaaS clichés

AESTHETIC LOCK
dark-mode native | neon-accent sparse | typography-first | hierarchy clear`},
  {label:"📱 Mobile",desc:"React Native / Expo components",content:`You are a senior React Native developer.
Build a mobile-first component for [platform: iOS / Android / both].

FUNCTIONAL REQUIREMENTS
- [describe feature]
- Gesture support (swipe, pinch, long-press)
- Offline-capable where applicable

TECHNICAL STACK
- Framework: React Native / Expo
- Navigation: Expo Router
- Animation: Reanimated 3

CONSTRAINTS
- 44px minimum touch targets
- Safe-area insets handled
- Dark mode as default
- Haptic feedback on key interactions

OUTPUT: Complete component with full source code and usage example.`},
  {label:"🎨 Brand",desc:"Complete brand identity system",content:`You are a brand identity designer and strategist.
Build a complete brand system for [brand name].

DELIVERABLES
1. Brand positioning statement (1 sentence)
2. Color palette (primary, secondary, accent, semantic)
3. Typography scale (display, heading, body, caption, mono)
4. Motion language (easing, duration, bias direction)
5. Design rules (5 core principles)
6. Tone of voice (3 adjectives + what to avoid)
7. CSS design tokens for the system

CONSTRAINTS
- Dark-mode native
- WCAG AA contrast ratios minimum
- Works across digital + print
- No trend-chasing — timeless over trendy`},
  {label:"🚀 Landing Page",desc:"High-conversion landing page",content:`You are a conversion-focused UI designer and copywriter.
Build a high-conversion landing page for [product/service].

PAGE ARCHITECTURE
1. Hero — hook + visual + primary CTA
2. Problem/Agitation — 3 pain points
3. Solution — features in bento grid
4. Social Proof — testimonials or metrics
5. Pricing — clear tiers with contrast CTA
6. FAQ — 5 objection-handling questions
7. Final CTA — urgency + benefit summary

COPY RULES
- Headline: benefit-first, not feature-first
- No corporate speak
- Every section earns attention before asking for action

TECHNICAL
- Next.js + Tailwind + Framer Motion
- Mobile-first, 60fps, Core Web Vitals optimized`},
  {label:"📊 Dashboard",desc:"Analytics dashboard with data viz",content:`You are a senior product designer specializing in data visualization.
Build an analytics dashboard for [use case].

LAYOUT
- 12-column responsive grid
- KPI cards row at top
- Chart section below
- Data table at bottom
- Collapsible sidebar navigation

DATA VISUALIZATION
- KPI cards: number + trend indicator + sparkline
- Line charts: time-series trends
- Bar charts: comparisons
- Tables: sortable, filterable, paginated

INTERACTIONS: Date range picker, filter panel, drill-down, CSV export

TECHNICAL: React + Recharts, Tailwind CSS, dark mode native, skeleton loading`},
  {label:"⚙️ API Design",desc:"REST/GraphQL spec + documentation",content:`You are a senior API architect.
Design a RESTful API for [service/domain].

RESOURCE DESIGN
- List all resources (nouns, not verbs)
- Define relationships (1:1, 1:N, N:N)
- Map CRUD operations to HTTP methods

ENDPOINT SPEC — For each endpoint:
- HTTP method + path
- Request schema (headers, params, body)
- Response schema (success + error)
- Rate limit policy + auth requirement

DOCUMENTATION OUTPUT
Generate OpenAPI 3.0 specification with:
- Complete schema definitions
- Example request/response pairs
- Error code catalogue
- Authentication flow

CONSTRAINTS: RESTful conventions, pagination on all list endpoints`},
];

const LAYERS=[
  {n:"01",name:"Role",       pur:"Who the AI acts as",           miss:"Generic, shallow responses"},
  {n:"02",name:"Context",    pur:"Product, audience, platform",  miss:"Misaligned output"},
  {n:"03",name:"Objective",  pur:"What success looks like",      miss:"Aimless generation"},
  {n:"04",name:"Constraints",pur:"Quality guardrails",           miss:"Mediocre, unconstrained output"},
  {n:"05",name:"Aesthetic",  pur:"Design language / tone",       miss:"Visually dull or off-brand"},
  {n:"06",name:"Planning",   pur:"Reason before generating",     miss:"Structural mistakes"},
  {n:"07",name:"Output",     pur:"Exact format to deliver",      miss:"Incomplete or disorganized files"},
  {n:"08",name:"Refinement", pur:"Self-critique before final",   miss:"First-draft quality only"},
];

const LAYER_TPL=`ROLE
You are a [expert role].

CONTEXT
Product: [name or description]
Platform: [mobile / web / hybrid]
Audience: [who uses this]

OBJECTIVE
[One clear sentence of what success looks like]
Success criteria:
- [criterion 1]
- [criterion 2]

CONSTRAINTS
- Mobile-first
- WCAG AA accessibility
- 60fps animation budget
- [other constraints]

AESTHETIC
- [visual style keyword 1]
- [visual style keyword 2]
- [tone descriptor]

PLANNING (complete this before generating)
1. Define information architecture
2. Define navigation model
3. Define layout and grid
4. Define interaction and motion logic
5. Validate accessibility and performance plan

OUTPUT FORMAT
Generate:
1. [file or artifact type]
2. [second deliverable]
3. [instructions or explanation]

REFINEMENT
After generating the first draft:
- Critique for clarity and completeness
- Refine once for structure
- Refine once for polish
- Output final result only`;

const ANIMALS=[
  {name:"Rabbit",  emoji:"🐇",mode:"Multiply Ideas",         prompt:"Take this idea and multiply it into 10 different variations.\nFor each variation: change the angle, change the audience, change the format.\nPresent the results as a list of distinct ideas."},
  {name:"Owl",     emoji:"🦉",mode:"Deep Analysis",          prompt:"Think like an owl — slow, observant and analytical.\nExamine this problem from multiple perspectives and identify\nthe hidden factors most people overlook."},
  {name:"Ant",     emoji:"🐜",mode:"Break Into Steps",       prompt:"Think like an ant.\nBreak this goal into the smallest possible steps someone could realistically complete."},
  {name:"Eagle",   emoji:"🦅",mode:"Big Picture Strategy",   prompt:"Think like an eagle flying high above the landscape.\nExplain the long-term strategy behind this idea and how the pieces connect."},
  {name:"Dolphin", emoji:"🐬",mode:"Creative Solutions",     prompt:"Think like a dolphin — curious, playful and inventive.\nGenerate creative solutions to this problem that most people wouldn't normally consider."},
  {name:"Beaver",  emoji:"🦫",mode:"Build Systems",          prompt:"Think like a beaver building a dam.\nDesign a practical system that solves this problem step by step."},
  {name:"Elephant",emoji:"🐘",mode:"Cross-Field Connections",prompt:"Think like an elephant with a powerful memory.\nConnect this idea to insights from other fields such as\npsychology, economics, science or history."},
];

const CHAINS=[
  {goal:"Build AI Content System", c:["Eagle","Beaver","Ant"],    best:"Automated content pipelines"},
  {goal:"Solve Complex Problem",   c:["Owl","Dolphin","Elephant"],best:"Product design, breakthrough features"},
  {goal:"Brainstorm Product",      c:["Rabbit","Eagle","Ant"],    best:"Product ideation, channel selection"},
  {goal:"Design Workflow",         c:["Beaver","Ant","Owl"],      best:"Automation scripts, SOPs"},
  {goal:"Validate Business",       c:["Owl","Elephant","Eagle"],  best:"Startup validation, venture assessment"},
  {goal:"Generate Viral Content",  c:["Rabbit","Dolphin","Eagle"],best:"Social media, marketing campaigns"},
];

const META={
  universal:`You are a [senior role].

Step 1: Analyze and rewrite the concept into a structured brief including:
- Target audience and their goals
- UX objectives
- Platform constraints
- Aesthetic system
- Interaction model

Step 2: Plan the architecture:
- Navigation model
- Layout grid
- Motion and animation system
- Accessibility plan

Step 3: Generate the final output in [tool or framework].

Concept: [your idea]`,
  mobile:`Plan mobile-first architecture:
- Bottom navigation with gesture support
- 44px minimum touch targets
- Swipe gesture patterns
- Haptic feedback cues
- Safe-area insets handled
- Dark mode as default
Then generate [React Native / Expo] components with full source code.`,
  web:`Plan web architecture:
- 8pt baseline grid
- Responsive breakpoints: 375px, 768px, 1280px, 1920px
- Navigation: [top nav / sidebar / hybrid]
- Scroll-trigger animations via Framer Motion
- Semantic HTML structure
- SEO meta tags included
Then generate Next.js + Tailwind components with full source code.`,
};

const ENH=[
  {label:"Self-Refinement Loop",content:`Generate draft →
Critique on: sophistication, uniqueness, performance, platform alignment →
Refine once for structure →
Refine once for polish and consistency →
Output final result only.

Max: 2 refinement passes. 3 absolute maximum. Never regenerate from scratch.`},
  {label:"Chain-of-Thought (CoT)",content:`Let's think step by step.

[Append this to any complex prompt to trigger deeper reasoning.]

Best for: multi-step flows, system design, checkout flows, onboarding journeys.`},
  {label:"Self-Consistency",content:`Generate [6-12] layout/approach variants.
Identify the strongest structural patterns across all variants.
Merge the best attributes into one final output.

Best for: preventing average-output drift when you need genuinely creative results.`},
  {label:"Tweak Protocol",content:`Refine [specific element] with [specific change].
Lock aesthetic. Preserve hierarchy. Maintain code quality.
Do not change anything else.

Best for: Change one variable at a time. Precision beats full regeneration every time.`},
  {label:"Prompt Diff",content:`Compare Prompt A and Prompt B.
For each, score on: clarity, constraints, predictability, output specificity.
Explain what changed between versions and why one performs better.

Use this to A/B test prompt versions before committing to a final.`},
];

const WEB_VARS=[
  {id:"dev",  label:"DEVELOPER",        desc:"Full Next.js + Tailwind + Framer Motion project"},
  {id:"pd",   label:"PRODUCT DESIGNER", desc:"Ultra-modern web app with design rationale"},
  {id:"sf",   label:"STARTUP FOUNDER",  desc:"Startup-ready premium mobile-first interface"},
  {id:"info", label:"INFOGRAPHIC",      desc:"Dynamic infographic with scroll interactions"},
  {id:"genz", label:"GEN-Z UI",         desc:"Neon gradients, animated typography, dark-mode"},
  {id:"ai",   label:"AI PRODUCT",       desc:"Complete app with Next.js + Tailwind + GSAP"},
  {id:"nc",   label:"NO-CODE",          desc:"Implementable in low-code tools"},
  {id:"edu",  label:"EDUCATIONAL",      desc:"Demo that teaches through visual interaction"},
  {id:"port", label:"PORTFOLIO",        desc:"Ultra-modern minimal with smooth transitions"},
  {id:"exp",  label:"EXPERIMENTAL",     desc:"Bold Gen-Z, scroll triggers, dark mode default"},
];

const DOLPHIN_C=[
  "Scroll as Navigation — sections animate like chapters",
  "Skill Map Interface — interactive node graph",
  "AI-assisted UI — user types and interface rearranges",
  "Card-based micro-apps — each card opens a mini tool",
  "Data-driven storytelling — charts animate on scroll",
  "Gesture-first mobile — swipe navigation instead of menus",
  "AI search panel — natural language search filters",
  "Live theme switcher — neon / minimal / glass toggle",
  "Canvas mode — user manipulates elements visually",
  "Interactive infographic — site as moving infographic",
];

const JSON_GLOBAL=`Respond EXCLUSIVELY with valid JSON — no explanations, no markdown fences, no extra text.
Use double quotes only. No trailing commas. No comments inside JSON.
Unknown values use "TBD". Output must pass JSON.parse() without errors.`;

const JSON_T=[
  {id:"t1",label:"T1 — Role + Strict Schema",badge:"Zero-shot baseline",color:C.gn,when:"First attempt, any capable model",content:`You are an expert [role].
Analyze the input and respond EXCLUSIVELY with valid JSON.
Use this exact schema:
{
  "sitemap": [ { "page_slug": "", "page_title": "", "description": "" } ],
  "pages": {
    "<slug>": {
      "sections": [ { "type": "", "heading": "", "content": "" } ],
      "seo": { "meta_title": "", "meta_description": "" }
    }
  },
  "global": { "site_title": "", "tagline": "", "color_palette": "" },
  "image_prompts": [ "descriptive string for image generation" ]
}
Input: [your input here]`},
  {id:"t2",label:"T2 — Few-Shot Examples",badge:"Best for local models",color:C.vi,when:"Inconsistent output (Ollama/local)",content:`Example 1:
Input: "A freelance photographer portfolio site"
Output: { ...valid JSON... }

Example 2:
Input: "Local gym with classes and membership info"
Output: { ...valid JSON... }

Now process:
Input: "[real input]"
Output:`},
  {id:"t3",label:"T3 — CoT + Structured",badge:"Fix structural errors",color:C.am,when:"Structure keeps being wrong",content:`First, think step by step internally:
1. Identify core type and goals.
2. List essential entities.
3. For each entity, identify 3-5 properties.
4. Draft descriptions and labels.
Then output ONLY the JSON. Do not include your reasoning in the output.`},
  {id:"t4",label:"T4 — Validation Guardrails",badge:"Always append",color:C.cy,when:"Add to any technique above",content:`After generating the JSON:
- Verify all keys match the schema exactly
- Check for trailing commas and fix them
- Confirm all strings use double quotes
- Replace any undefined values with "TBD"
- Ensure the result passes JSON.parse() without errors`},
];

const JSON_MX=[
  {sit:"First attempt, any capable model",    use:"T1 + T4"},
  {sit:"Inconsistent output (Ollama/local)",  use:"T1 + T2 + T4"},
  {sit:"Structure keeps being wrong",         use:"T1 + T3 + T4"},
  {sit:"All else fails",                      use:"T1 + T2 + T3 + T4"},
];

const VOCAB=[
  {t:"glassmorphism",     d:"Frosted glass panels — translucent, blurred backdrop",  cat:"core"},
  {t:"brutalist ui",      d:"Raw, oversized, high-contrast, intentionally rough",    cat:"core"},
  {t:"kinetic typography",d:"Text that animates, morphs, or reacts to scroll",      cat:"core"},
  {t:"bento grid",        d:"Mosaic card layout — Apple-style asymmetric grid",      cat:"core"},
  {t:"micro-interactions",d:"Tiny animations on hover, click, scroll, focus",       cat:"core"},
  {t:"neon accent",       d:"Single bright color pop against a dark background",    cat:"core"},
  {t:"liquid gradient",   d:"Smooth, animated, shifting background color blends",   cat:"core"},
  {t:"dark-mode native",  d:"Designed for dark backgrounds first, light second",    cat:"core"},
  {t:"skeleton loading",  d:"Placeholder shimmer before real content appears",      cat:"motion"},
  {t:"ambient motion",    d:"Subtle, looping background animation",                 cat:"motion"},
  {t:"progressive disclosure",d:"Reveal complexity only when user needs it",        cat:"motion"},
  {t:"editorial layout",  d:"Magazine-style, large typography, asymmetric grid",    cat:"motion"},
  {t:"neo-brutalism",     d:"Bold shadows, flat colors, thick borders",             cat:"adv"},
  {t:"aurora gradients",  d:"Soft flowing northern lights effect",                  cat:"adv"},
  {t:"noise grain",       d:"Textured overlay adding depth",                        cat:"adv"},
  {t:"blur overlay",      d:"Background blur for focus and depth",                  cat:"adv"},
  {t:"morph shapes",      d:"Organic transforming shapes",                          cat:"adv"},
  {t:"tilt 3d",           d:"Parallax depth on cards",                              cat:"adv"},
  {t:"custom cursor",     d:"Personalized cursor design",                           cat:"adv"},
  {t:"particle systems",  d:"Interactive floating elements",                        cat:"adv"},
  {t:"scanline effect",   d:"Retro CRT horizontal lines",                           cat:"adv"},
  {t:"vignette",          d:"Darkened edges for focus",                             cat:"adv"},
  {t:"chromatic aberration",d:"RGB split glitch effect",                            cat:"adv"},
  {t:"mesh gradient",     d:"Multi-color organic blending",                         cat:"adv"},
  {t:"claymorphism",      d:"3D soft plastic appearance",                           cat:"adv"},
  {t:"fiber background",  d:"Fiber optic light patterns",                           cat:"adv"},
  {t:"isotype system",    d:"Repeating graphic symbols",                            cat:"adv"},
  {t:"duotone",           d:"Two-color image treatment",                            cat:"adv"},
];

const COMBOS=[
  {combo:"🫧 Glass + Bento",    els:"glassmorphism, bento grid, dark-mode",        best:"Dashboards, data viz",       psych:"Depth + hierarchy + scannability"},
  {combo:"💥 Brutal + Neon",    els:"brutalist, neon accent, kinetic",             best:"Landing pages, bold brands", psych:"Urgency + attention + focus"},
  {combo:"🌊 Liquid + Ambient", els:"liquid gradient, ambient motion",             best:"Hero sections, immersive",   psych:"Emotion + flow + atmosphere"},
  {combo:"📰 Editorial + Bento",els:"editorial, bento grid, progressive",          best:"Content platforms, blogs",   psych:"Authority + modern organization"},
  {combo:"✨ Micro + Skeleton",  els:"micro-interactions, skeleton loading",        best:"Apps, data-heavy interfaces",psych:"Reduced perceived wait time"},
  {combo:"🚀 Full Immersive",   els:"kinetic, liquid, micro, ambient",             best:"Marketing sites, launches",  psych:"Maximum engagement"},
  {combo:"🎮 Cyberpunk Glow",   els:"neon, chromatic, scanline, dark",            best:"Gaming, crypto, tech",       psych:"Futuristic + innovation"},
  {combo:"💎 Premium Minimal",  els:"glass, noise grain, duotone",                best:"Luxury brands",              psych:"Exclusivity + sophistication"},
  {combo:"🧸 Playful 3D",       els:"claymorphism, morph, tilt, cursor",          best:"Kids apps, gamified",        psych:"Friendly + approachable"},
  {combo:"🌐 Fiber Tech",       els:"fiber, particles, mesh, liquid",             best:"Telecom, networks",          psych:"Connectivity + speed"},
  {combo:"🎬 Cinematic",        els:"vignette, blur, kinetic, ambient",           best:"Film, media",                psych:"Movie-like atmosphere"},
  {combo:"📊 Isotype Data",     els:"isotype, bento, skeleton, duotone",          best:"Statistics, reports",        psych:"Data digestible + memorable"},
];

const TYPO=[
  {d:"Space Grotesk",m:"JetBrains Mono",b:"Tech startups, developer tools, modern SaaS"},
  {d:"Syne Bold",    m:"JetBrains Mono",b:"Creative agencies, art portfolios, bold brands"},
  {d:"Clash Display",m:"Space Mono",    b:"Fashion, luxury brands, premium products"},
  {d:"Inter Tight",  m:"JetBrains Mono",b:"Dashboards, enterprise apps, content platforms"},
];

const TYPO_I=[
  {u:"Data Viz", c:"Space Grotesk (headers) + Inter (body) + JetBrains Mono (numbers)"},
  {u:"Creative", c:"Syne (display) + Space Grotesk (body) + Clash Display (accent)"},
  {u:"Mobile",   c:"Inter Tight (headlines) + Inter (body) + SF Pro (UI)"},
];

const BRAND=`Brand essence: Activated potential. Directed energy. Intelligent lift.

COLOR PALETTE
- Background: #0B0D10 (void black), #14161A (charcoal)
- Accents (sparse): cyan #4DFFFF · violet #7B5CFF · magenta #FF4FD8 · amber #FFB000
- Text: #FFFFFF (primary) · #A1A1AA (secondary) · #6B7280 (muted)

TYPOGRAPHY
- Display: Inter, Space Grotesk · Body: Inter · Mono: JetBrains Mono
- Hero: clamp(3rem, 6vw, 6rem)

MOTION
- Bias: always upward
- Easing: cubic-bezier(0.16, 1, 0.3, 1)
- Duration: micro 180ms · standard 320ms · hero 4200ms

DESIGN RULES
- Typography-first — type does the work, effects support
- Dark-mode native · One accent color per screen maximum
- White space = intelligence, never fill it
- No gradients unless motion-driven · No icons unless semantically necessary

TONE: Confident. Modern. Calm. Inevitable.
AVOID: over-decoration · excessive gradients · visual noise · SaaS clichés`;


const BRANDS=[
  {id:"powerup",label:"powerUP",uc:"Motivational / Creator / Personal Brand",col:C.cy,prompt:BRAND},
  {id:"saas",label:"SaaS / B2B",uc:"SaaS Platform, B2B Product, Enterprise Tool",col:C.bl,prompt:`Brand essence: Clarity that converts. Trust that scales. Tools that actually work.

COLOR PALETTE
Background: F8FAFC (light) / 0F172A (dark). Primary: 2563EB trust blue. Secondary: 7C3AED violet.
Accent: 10B981 success. Warning: F59E0B. Error: EF4444. Text: 0F172A.

TYPOGRAPHY
Display: Inter Tight ExtraBold. Body: Inter. Mono: JetBrains Mono. Scale: 12/14/16/20/24/32/40px.

MOTION
Duration: 150ms micro, 250ms standard. NO hero animations. ease-out entries, ease-in exits.
Zero animations blocking user intent.

DESIGN RULES
1 Function before form. 2 Information hierarchy above all. 3 States for everything.
4 Mobile-first. 5 WCAG AA minimum.

VOICE: Clear. Competent. Empathetic. Never smug.
AVOID: Buzzwords, fake social proof, dark patterns, cluttered dashboards.`},
  {id:"ecomm",label:"E-commerce",uc:"Retail, DTC Brand, Product Marketplace",col:C.gn,prompt:`Brand essence: Desire made visible. Trust made immediate. Conversion made inevitable.

COLOR PALETTE
CTA: maximum contrast to page background. Sale/urgency: EF4444 or F59E0B (sparingly).
Trust signals: white backgrounds, high-contrast product photography.

TYPOGRAPHY
Display: ownable brand typeface (not generic). Body: System UI (fast load).
Price/number: font-variant-numeric:tabular-nums (numbers must align in columns).

UX RULES
1 CTA above fold on every product page.
2 Price visible without hover. Shipping cost shown early.
3 Cart from every page. Checkout in 3 steps max.
4 Mobile: thumb-zone CTAs, 44px touch targets.
5 Trust signals near CTA: reviews, security badges, return policy.

VOICE: Aspirational but honest. Enthusiastic but not desperate.
AVOID: Fake urgency, hidden fees, dark patterns, slow image loading.`},
  {id:"fintech",label:"Fintech",uc:"Finance, Banking, Investment App",col:C.am,prompt:`Brand essence: Money made clear. Risk made visible. Wealth made accessible.

COLOR PALETTE — CRITICAL MEANING RULES
Positive/gain: 10B981 emerald ONLY. Negative/loss: EF4444 red ONLY.
NEVER use red for branding. NEVER use green decoratively.
Primary brand: deep navy or forest green (stability). Background: FFFFFF / 0F172A.

TYPOGRAPHY — MANDATORY
Numbers: font-variant-numeric:tabular-nums (data must align).
Display: Instrument Sans or Plus Jakarta Sans. Body: Inter. Mono: IBM Plex Mono.

DATA VISUALIZATION RULES
1 Color-code by meaning not aesthetics.
2 Show uncertainty: error bars, confidence intervals.
3 Zero-line always visible on charts.
4 Currency: symbol + 2 decimal places + thousand separators always.
5 Percentages: always show absolute value alongside.

MOTION: Minimal. Number countup: 500ms max. Finance users are anxious.
VOICE: Clear. Precise. Reassuring. Never patronizing.
AVOID: Gambling language, hidden fees, false urgency.`},
  {id:"insurance",label:"Insurance",uc:"Insurtech, Benefits Platform, Insurance Brand",col:"#7B5CFF",prompt:`Brand essence: Protection made personal. Claims made simple. Trust made tangible.

COLOR PALETTE
Primary: 1E3A5F deep navy (authority, stability, trust).
Secondary: 2563EB action blue. Accent: 10B981 approval green.
Warning: F59E0B. Error: EF4444. Background: FFFFFF. Surface: F0F4F8.

CRITICAL COLOR MEANING
Green = approved / covered / positive. Red = denied / uncovered / urgent.
Blue = action, CTA, links. Consistent meaning across ALL touchpoints.

TYPOGRAPHY
Display: Plus Jakarta Sans Bold (trustworthy, modern, human).
Body: Inter (maximum readability for policy documents).
Numbers: tabular-nums. Legal fine print: minimum 12px, never below WCAG AA.

COPY RULES
1 Plain language over legal jargon. Every policy term gets a simple explanation.
2 Covered = green check. Not covered = neutral gray (never red for not-covered).
3 Price always transparent. No call-for-quote dark patterns.
4 Claims process: exact steps, expected timeline, required documents listed.
5 Social proof: real claim settlement data, not just star ratings.

UX RULES
1 Quote flow: max 3 steps before showing a price.
2 Coverage comparison: side-by-side, no buried exclusions.
3 Claims: one-tap start, photo upload, status tracking like a package.
4 Documents: searchable, filterable, download as PDF.
5 Notifications: claims updates, renewal reminders, payment confirmations.

TRUST SIGNALS (non-negotiable near every CTA)
Licensed status. AM Best or financial rating. Real avg claim processing times.
Privacy policy link near every data collection point.

MOTION: Minimal and purposeful. Progress indicators for multi-step flows.
Status micro-animation: pending to approved (green sweep, 400ms).
NEVER: spinners over 2s, confetti on claim submission.

VOICE: Honest. Clear. Protective. Warm. Never cold or bureaucratic.
AVOID: Fine print as design, ambiguous coverage, fear-based selling,
complexity theater, dark patterns on cancellation flows.`},
  {id:"agency",label:"Creative Agency",uc:"Design Studio, Production House",col:C.mg,prompt:`Brand essence: Ideas made real. Craft made obvious. Work that wins.

COLOR PALETTE
Philosophy: the work IS the brand. Neutral shell lets portfolio shine.
Background: 000000 or F5F5F0 — pick one, commit fully.
Accent: ONE ownable color only (not cyan, not purple, not generic orange).

TYPOGRAPHY
Display: unusual, ownable — Roc Grotesk, Euclid Circular, Mabry Pro.
Body: most neutral companion — GT America, Aktiv Grotesk.
Size: LARGE. 80-120px display, 18px body minimum. Tight leading (0.9-1.0) for display.

MOTION
Page transitions: GSAP or Barba.js clip-path wipes.
Cursor: custom oversized dot/ring with magnetic pull on buttons.
Scroll velocity influences animation speed via GSAP ScrollTrigger.
Load sequence: logo reveal, content stagger, cursor activate.

DESIGN RULES
1 The work leads. UI never competes with portfolio.
2 Whitespace is the design. Generous margins, radical restraint.
3 One typeface mastered before adding another.
4 Every hover state tells a story.
5 Case study order: Problem, Process, Solution, Impact.

VOICE: Confident to the point of understatement. Let the work talk.
AVOID: Stock photos, generic templates, Lorem ipsum in production.`},
];
const LINT=[
  {id:"missing-role",         check:"Does the prompt define who the AI should act as?",   auto:true, fix:"Add default role"},
  {id:"missing-constraints",  check:"Does the prompt define explicit limits?",            auto:true, fix:"Add mobile-first, WCAG, 60fps"},
  {id:"missing-objective",    check:"Does the prompt state a clear success condition?",   auto:false,fix:"Must be user-defined"},
  {id:"vague-language",       check:"Does it use: nice, cool, awesome?",                 auto:true, fix:"Replace with specific terms"},
  {id:"missing-output-format",check:"Does it specify what files/format to generate?",    auto:false,fix:"Must be user-defined"},
  {id:"missing-planning",     check:"For UI prompts, is there a planning phase?",         auto:false,fix:"Must be user-defined"},
];
const SWAPS=[["nice","clear and intentional"],["cool","high-contrast and dynamic"],["modern","[specific aesthetic keyword]"],["awesome","visually striking and purposeful"],["good design","typographically strong with clear hierarchy"]];
const CHECKS=[
  {lbl:"STRUCTURE",items:["Role defined — who is the AI acting as?","Goal clear — one sentence maximum","Objective and success criteria stated","Constraints listed explicitly (not implied)"]},
  {lbl:"DESIGN (UI/UX prompts)",items:["Platform specified — mobile or web or hybrid","3+ aesthetic keywords included","Animation library named — Framer Motion or GSAP or None","Mobile-first stated explicitly"]},
  {lbl:"TECHNICAL",items:["Stack specified — framework + styling + animation","Output format requested — folder + files + instructions","Accessibility: WCAG AA minimum stated","Performance: 60fps animation budget stated"]},
  {lbl:"QUALITY",items:["No vague words — nice, cool, awesome, modern, good","Refinement instruction included","At least one interaction metaphor defined","JSON rules appended if requesting structured data"]},
  {lbl:"ANIMAL MODE (optional)",items:["Mode selected: Beaver / Dolphin / Eagle / Ant / Owl / Rabbit / Elephant","Or chained for complex goals: Eagle → Beaver → Ant"]},
];
const SDIMS=[
  {name:"Clarity",      what:"Is the goal unambiguous? No vague language?"},
  {name:"Structure",    what:"Does it follow ROLE → CONTEXT → OBJECTIVE → OUTPUT?"},
  {name:"Constraints",  what:"Mobile-first? Accessibility? Performance?"},
  {name:"Predictability",what:"Does it specify output format and refinement?"},
];
const SSCALE=[
  {r:"9–10",level:"Production ready",    action:"Ship it",                      col:C.gn},
  {r:"7–8", level:"Good, minor gaps",    action:"Add missing constraints",      col:"#84cc16"},
  {r:"5–6", level:"Partial structure",   action:"Add role + output format",     col:"#eab308"},
  {r:"3–4", level:"Weak, vague",         action:"Rebuild with 8-layer template",col:C.or},
  {r:"1–2", level:"Single vague sentence",action:"Start over",                  col:C.rd},
];

const WF=[
  {id:1,cat:"🎨 Design",title:"Design System Creation",purpose:"Build complete design system",best:"New products, rebrands",chain:["Eagle","Beaver","Ant","Owl"],out:"Complete design system with color tokens, typography, and component library",steps:[
    {a:"Eagle", t:"Define long-term design vision",items:["Brand positioning and personality","Target audience demographics","Competitive landscape analysis","Design principles (3-5 core values)"]},
    {a:"Beaver",t:"Build foundational components",items:["Color palette (primary, secondary, accent, semantic)","Typography scale (display, heading, body, caption)","Spacing system (4px baseline grid)","Border radius and shadow scales"]},
    {a:"Ant",   t:"Create component library",items:["Buttons (primary, secondary, ghost, icon)","Form elements (input, select, checkbox, radio)","Cards and containers","Navigation patterns"]},
    {a:"Owl",   t:"Validate consistency",items:["Check all components follow the system","Verify accessibility contrast ratios","Test responsive behavior"]},
  ]},
  {id:2,cat:"🎨 Design",title:"Landing Page Design",purpose:"Create high-conversion landing page",best:"Marketing, startups",chain:["Rabbit","Eagle","Beaver","Ant"],out:"Complete landing page with all sections and conversion optimizations",steps:[
    {a:"Rabbit",t:"Generate 10+ headline variations",items:["Problem-aware headlines","Solution-focused headlines","Benefit-driven headlines","Social proof headlines"]},
    {a:"Eagle", t:"Structure the page architecture",items:["Hero section with CTA","Problem/Agitation section","Solution/features section","Social proof section","Pricing/CTA section"]},
    {a:"Beaver",t:"Design each section",items:["Hero: Hook + visual + CTA","Features: 3-column bento grid","Testimonials: Carousel or grid","CTA: Contrast section"]},
    {a:"Ant",   t:"Optimize for conversion",items:["Button placement and sizing","Form field minimization","Loading states","Mobile touch targets"]},
  ]},
  {id:3,cat:"🎨 Design",title:"Dashboard Design",purpose:"Build data visualization dashboard",best:"Analytics, SaaS products",chain:["Eagle","Beaver","Dolphin","Ant"],out:"Interactive dashboard with all widgets and filtering capabilities",steps:[
    {a:"Eagle",  t:"Define data requirements",items:["Key metrics and KPIs","User roles and permissions","Data refresh frequency","Export requirements"]},
    {a:"Beaver", t:"Layout the grid",items:["12-column responsive grid","Widget sizing standards","Gutter and margin system","Breakpoint definitions"]},
    {a:"Dolphin",t:"Choose visualization types",items:["KPI cards for single metrics","Line charts for trends","Bar charts for comparisons","Tables for detailed data"]},
    {a:"Ant",    t:"Implement interactions",items:["Filter mechanisms","Date range selectors","Drill-down capabilities","Export functions"]},
  ]},
  {id:4,cat:"💻 Dev",title:"Full-Stack App Development",purpose:"Build complete web application",best:"Product builds",chain:["Eagle","Beaver","Ant","Owl"],out:"Production-ready application with full documentation",steps:[
    {a:"Eagle", t:"Define product architecture",items:["Core features list","User flows and journeys","Data models and relationships","API boundaries"]},
    {a:"Beaver",t:"Set up project structure",items:["Repository initialization","Dependencies configuration","Environment setup","Linting and formatting rules"]},
    {a:"Ant",   t:"Implement feature by feature",items:["Database schema","API endpoints","Frontend components","Integration testing"]},
    {a:"Owl",   t:"Review and optimize",items:["Code quality audit","Performance profiling","Security vulnerability check","Documentation completion"]},
  ]},
  {id:5,cat:"💻 Dev",title:"API Design",purpose:"Design RESTful or GraphQL API",best:"Backend development",chain:["Owl","Beaver","Ant","Dolphin"],out:"Complete API specification with OpenAPI documentation",steps:[
    {a:"Owl",    t:"Analyze requirements",items:["Resource identification","Relationship mapping","Authentication needs","Rate limiting requirements"]},
    {a:"Beaver", t:"Define endpoints",items:["HTTP methods selection","URL structure design","Request/response schemas","Error handling strategy"]},
    {a:"Ant",    t:"Document comprehensively",items:["OpenAPI/Swagger specification","Example requests/responses","Authentication docs","Rate limit documentation"]},
    {a:"Dolphin",t:"Add advanced features",items:["Pagination strategies","Filtering and sorting","Caching headers","Webhook support"]},
  ]},
  {id:6,cat:"💻 Dev",title:"Database Schema Design",purpose:"Design scalable database structure",best:"Data modeling",chain:["Eagle","Beaver","Ant","Owl"],out:"Production database schema with migration scripts",steps:[
    {a:"Eagle", t:"Map data requirements",items:["Entity identification","Relationship types (1:1, 1:N, N:N)","Data volume estimation","Performance requirements"]},
    {a:"Beaver",t:"Design schema",items:["Table/collection definitions","Column types and constraints","Index strategy","Foreign key relationships"]},
    {a:"Ant",   t:"Implement migrations",items:["Up migration scripts","Seed data scripts","Rollback procedures","Migration testing"]},
    {a:"Owl",   t:"Optimize for performance",items:["Query analysis","Index refinement","Partitioning strategy","Backup procedures"]},
  ]},
  {id:7,cat:"📈 Business",title:"Product Roadmap Planning",purpose:"Create strategic product roadmap",best:"Product management",chain:["Owl","Eagle","Rabbit","Beaver"],out:"Prioritized product roadmap with timeline and milestones",steps:[
    {a:"Owl",   t:"Analyze current state",items:["Market analysis","Competitive landscape","User feedback review","Technical debt assessment"]},
    {a:"Eagle", t:"Define vision",items:["12-month product vision","Key objectives and OKRs","Success metrics","Risk identification"]},
    {a:"Rabbit",t:"Generate initiatives",items:["Feature proposals","Technical improvements","Infrastructure needs","Research projects"]},
    {a:"Beaver",t:"Prioritize and sequence",items:["Impact vs effort scoring","Dependency mapping","Resource allocation","Milestone planning"]},
  ]},
  {id:8,cat:"📈 Business",title:"Market Research",purpose:"Conduct comprehensive market analysis",best:"Business strategy",chain:["Owl","Elephant","Ant","Eagle"],out:"Market research report with actionable insights",steps:[
    {a:"Owl",     t:"Define research scope",items:["Target market definition","Competitor list","Research questions","Data sources identification"]},
    {a:"Elephant",t:"Gather insights",items:["Industry reports review","Competitor analysis","Customer interview synthesis","Trend analysis"]},
    {a:"Ant",     t:"Break down findings",items:["SWOT analysis","Market size estimation","User persona development","Opportunity mapping"]},
    {a:"Eagle",   t:"Synthesize recommendations",items:["Strategic positioning","Go-to-market suggestions","Pricing strategy","Risk mitigation"]},
  ]},
  {id:9,cat:"📈 Business",title:"User Onboarding Flow",purpose:"Design effective user onboarding",best:"Product growth",chain:["Owl","Dolphin","Beaver","Ant"],out:"Complete onboarding flow with metrics and testing plan",steps:[
    {a:"Owl",    t:"Understand user psychology",items:["Activation moment identification","Friction point analysis","Value moment mapping","Drop-off prediction"]},
    {a:"Dolphin",t:"Generate onboarding ideas",items:["Welcome emails","Interactive tutorials","Progress indicators","Social proof moments"]},
    {a:"Beaver", t:"Design the flow",items:["Sign-up to first value","Step-by-step guidance","Progress tracking","Celebration moments"]},
    {a:"Ant",    t:"Implement and test",items:["A/B test variations","Analytics tracking","Feedback loops","Iteration cycles"]},
  ]},
  {id:10,cat:"📝 Content",title:"Blog Content Creation",purpose:"Write SEO-optimized blog posts",best:"Content marketing",chain:["Owl","Eagle","Ant","Owl"],out:"Ready-to-publish blog post with SEO optimizations",steps:[
    {a:"Owl",  t:"Research topic",items:["Keyword analysis","Search intent identification","Competitor content review","Topic cluster mapping"]},
    {a:"Eagle",t:"Structure outline",items:["H2/H3 hierarchy","Key points to cover","Data and statistics to include","Internal linking strategy"]},
    {a:"Ant",  t:"Write section by section",items:["Compelling introduction","Body paragraphs with examples","Visual element suggestions","Strong conclusion"]},
    {a:"Owl",  t:"Optimize for SEO",items:["Meta title and description","URL structure","Alt text for images","Schema markup"]},
  ]},
  {id:11,cat:"📝 Content",title:"Video Content Strategy",purpose:"Plan and create video content",best:"YouTube, social media",chain:["Rabbit","Eagle","Beaver","Ant"],out:"Video content calendar with production assets",steps:[
    {a:"Rabbit",t:"Generate content angles",items:["10+ video topic ideas","Different formats (tutorial, vlog, review)","Audience variations","Trend adaptations"]},
    {a:"Eagle", t:"Select and strategize",items:["Choose best topics","Define target audience","Set success metrics","Plan distribution channels"]},
    {a:"Beaver",t:"Create production plan",items:["Script outline","B-roll requirements","Thumbnail concepts","Posting schedule"]},
    {a:"Ant",   t:"Execute and optimize",items:["Filming and editing","SEO optimization","Engagement strategy","Analytics review"]},
  ]},
  {id:12,cat:"📝 Content",title:"Email Marketing Campaign",purpose:"Design email marketing sequence",best:"Marketing automation",chain:["Owl","Rabbit","Beaver","Ant"],out:"Complete email campaign automation with all sequences",steps:[
    {a:"Owl",   t:"Define customer journey",items:["Funnel stages","Trigger events","Segment definitions","Goal mapping"]},
    {a:"Rabbit",t:"Generate email variations",items:["Welcome series ideas","Promo sequences","Re-engagement campaigns","Post-purchase flows"]},
    {a:"Beaver",t:"Write each email",items:["Subject line optimization","Preview text","Body copy","CTA buttons"]},
    {a:"Ant",   t:"Set up automation",items:["Trigger conditions","Timing intervals","A/B test variants","Unsubscribe handling"]},
  ]},
  {id:13,cat:"🔧 Automation",title:"Workflow Automation",purpose:"Design automated business process",best:"Operations, efficiency",chain:["Owl","Beaver","Ant","Owl"],out:"Production automation workflow with monitoring",steps:[
    {a:"Owl",   t:"Analyze current process",items:["Manual steps documentation","Time and resource costs","Error points identification","Bottleneck analysis"]},
    {a:"Beaver",t:"Design automation",items:["Trigger definition","Action sequence","Conditional logic","Error handling"]},
    {a:"Ant",   t:"Implement step by step",items:["API integrations","Data transformations","Notification system","Logging mechanism"]},
    {a:"Owl",   t:"Test and monitor",items:["Edge case testing","Performance monitoring","Alert configuration","Documentation"]},
  ]},
  {id:14,cat:"🔧 Automation",title:"CI/CD Pipeline Setup",purpose:"Build continuous integration/deployment",best:"Development ops",chain:["Eagle","Beaver","Ant","Owl"],out:"Complete CI/CD pipeline with monitoring",steps:[
    {a:"Eagle", t:"Define pipeline stages",items:["Code checkout","Dependency installation","Linting and formatting","Unit testing","Integration testing","Build creation","Deployment trigger"]},
    {a:"Beaver",t:"Configure tools",items:["GitHub Actions / GitLab CI","Environment variables","Secret management","Cache strategies"]},
    {a:"Ant",   t:"Set up each stage",items:["Test runner configuration","Build script creation","Deployment scripts","Rollback procedures"]},
    {a:"Owl",   t:"Implement monitoring",items:["Build status notifications","Deployment tracking","Performance metrics","Error alerting"]},
  ]},
  {id:15,cat:"🎯 Problem",title:"Debug Complex Issue",purpose:"Systematically debug production issues",best:"Engineering",chain:["Owl","Ant","Beaver","Eagle"],out:"Fixed issue with prevention measures",steps:[
    {a:"Owl",   t:"Gather information",items:["Error logs review","User reports collection","Environment details","Recent changes timeline"]},
    {a:"Ant",   t:"Isolate the problem",items:["Reproduce locally","Binary search debugging","Variable elimination","Hypothesis formation"]},
    {a:"Beaver",t:"Implement fix",items:["Root cause addressing","Solution implementation","Test case addition","Code review preparation"]},
    {a:"Eagle", t:"Prevent recurrence",items:["Add monitoring","Update documentation","Process improvement","Team knowledge sharing"]},
  ]},
  {id:16,cat:"🎯 Problem",title:"Technical Debt Resolution",purpose:"Address accumulated technical debt",best:"Engineering",chain:["Owl","Eagle","Beaver","Ant"],out:"Reduced technical debt with verified improvements",steps:[
    {a:"Owl",   t:"Audit current state",items:["Code complexity analysis","Test coverage review","Dependency age check","Performance baseline"]},
    {a:"Eagle", t:"Prioritize debt items",items:["Impact assessment","Effort estimation","Risk evaluation","Dependency mapping"]},
    {a:"Beaver",t:"Execute refactoring",items:["Smallest valuable first","Preserve behavior","Add tests first","Incremental changes"]},
    {a:"Ant",   t:"Validate improvements",items:["Performance verification","Test coverage increase","Code review completion","Documentation update"]},
  ]},
  {id:17,cat:"📊 Data",title:"Analytics Implementation",purpose:"Set up proper analytics tracking",best:"Data teams",chain:["Owl","Beaver","Ant","Dolphin"],out:"Complete analytics implementation with dashboards",steps:[
    {a:"Owl",    t:"Define metrics framework",items:["Business objectives","Key metrics identification","User journey mapping","Success events"]},
    {a:"Beaver", t:"Plan tracking setup",items:["Event taxonomy","Property definitions","User identification strategy","Cross-domain tracking"]},
    {a:"Ant",    t:"Implement tracking",items:["SDK installation","Event implementation","Conversion tracking","Custom dimensions"]},
    {a:"Dolphin",t:"Create dashboards",items:["Real-time monitoring","Funnel analysis","Cohort tracking","Custom reports"]},
  ]},
  {id:18,cat:"📊 Data",title:"Data Pipeline Construction",purpose:"Build reliable data processing pipeline",best:"Data engineering",chain:["Eagle","Beaver","Ant","Owl"],out:"Production data pipeline with monitoring",steps:[
    {a:"Eagle", t:"Design data architecture",items:["Source identification","Transformation logic","Storage requirements","Delivery destinations"]},
    {a:"Beaver",t:"Build pipeline components",items:["Extract scripts","Transform functions","Load processes","Validation checks"]},
    {a:"Ant",   t:"Implement error handling",items:["Retry logic","Dead letter queues","Alert mechanisms","Recovery procedures"]},
    {a:"Owl",   t:"Optimize and monitor",items:["Performance tuning","Cost optimization","Quality monitoring","SLA tracking"]},
  ]},
];

// ─── SHARED UI ────────────────────────────────────────────────────────────────
function Cp({text,sm=true,label}){
  const[ok,set]=useState(false);
  const copy=useCopy();
  const go=()=>{copy(text);set(true);setTimeout(()=>set(false),1800);};
  return <button onClick={go} style={{background:ok?"#22c55e18":"#ffffff08",border:`1px solid ${ok?"#22c55e55":"#ffffff18"}`,color:ok?C.gn:C.mu,borderRadius:6,padding:sm?"3px 10px":"8px 16px",fontSize:sm?10:12,fontFamily:C.mn,cursor:"pointer",transition:"all 0.2s",letterSpacing:"0.05em",whiteSpace:"nowrap",flexShrink:0}}>{ok?"✓ COPIED":(label||"COPY")}</button>;
}
function Lbl({text,color=C.cy}){return <div style={{fontSize:10,color,fontFamily:C.mn,letterSpacing:"0.12em",marginBottom:5,textTransform:"uppercase"}}>{text}</div>;}
function H3({children}){return <h3 style={{margin:"0 0 14px",fontSize:"clamp(14px,2vw,17px)",fontWeight:700,color:C.tx,letterSpacing:"-0.02em",fontFamily:C.ss}}>{children}</h3>;}
function Card({children,accent,pad="18px 20px",sx={}}){return <div style={{background:C.sur,border:`1px solid ${accent?accent+"22":C.bdr}`,borderRadius:12,padding:pad,...sx}}>{children}</div>;}
function Code({text,mh}){return(<div style={{position:"relative"}}><pre style={{background:C.bg,border:`1px solid ${C.bdr}`,borderRadius:8,padding:"12px 44px 12px 13px",fontSize:"clamp(10px,1.4vw,12px)",lineHeight:1.75,color:"#e4e4e7",fontFamily:C.mn,whiteSpace:"pre-wrap",wordBreak:"break-word",margin:0,maxHeight:mh||"none",overflowY:mh?"auto":"visible"}}>{text}</pre><div style={{position:"absolute",top:8,right:8}}><Cp text={text}/></div></div>);}
function Pill({label,active,color,onClick}){return <button onClick={onClick} style={{background:active?`${color}18`:"transparent",border:`1px solid ${active?color+"55":C.bdr}`,color:active?color:C.di,borderRadius:20,padding:"4px 11px",fontSize:"clamp(10px,1.4vw,11px)",fontFamily:C.mn,cursor:"pointer",transition:"all 0.15s",whiteSpace:"nowrap",lineHeight:1.6}}>{label}</button>;}
function Inp({label,value,onChange,ph}){return(<div style={{marginBottom:10}}>{label&&<div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:4}}>{label}</div>}<input value={value} onChange={e=>onChange(e.target.value)} placeholder={ph} style={{width:"100%",boxSizing:"border-box",background:C.bg,border:`1px solid ${C.bdr}`,borderRadius:8,padding:"9px 12px",color:C.tx,fontSize:13,fontFamily:C.ss,outline:"none"}}/></div>);}
function TA({label,value,onChange,ph,rows=4}){return(<div style={{marginBottom:10}}>{label&&<div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:4}}>{label}</div>}<textarea value={value} onChange={e=>onChange(e.target.value)} placeholder={ph} rows={rows} style={{width:"100%",boxSizing:"border-box",background:C.bg,border:`1px solid ${C.bdr}`,borderRadius:8,padding:"9px 12px",color:C.tx,fontSize:12,fontFamily:C.mn,outline:"none",resize:"vertical",lineHeight:1.6}}/></div>);}

// ─── ACTIVATE ─────────────────────────────────────────────────────────────────
function Activate(){
  const[tT,setTT]=useState(0);
  const[tM,setTM]=useState(0);
  return(<div style={{display:"grid",gap:14}}>
    <Card>
      <Lbl text="Paste into any AI system prompt field"/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}><H3>Master System Prompt</H3><Cp text={MASTER} sm={false}/></div>
      <Code text={MASTER} mh={220}/>
    </Card>
    <Card>
      <Lbl text="Add at session start for high-stakes work"/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}><H3>Advocate Mode</H3><Cp text={ADVOCATE} sm={false}/></div>
      <Code text={ADVOCATE}/>
    </Card>
    <Card>
      <Lbl text="Append to any prompt to boost output quality"/>
      <H3>Secret Sauce Modifiers</H3>
      <div style={{overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}>
          <thead><tr>{["Modifier","Effect"].map(h=><th key={h} style={{textAlign:"left",padding:"6px 10px",color:C.di,fontSize:10,fontFamily:C.mn,letterSpacing:"0.08em",borderBottom:`1px solid ${C.bdr}`}}>{h}</th>)}</tr></thead>
          <tbody>{MODS.map(([m,e],i)=><tr key={i} style={{borderBottom:`1px solid #ffffff06`}}><td style={{padding:"7px 10px",color:C.cy,fontFamily:C.mn,fontSize:11}}>{m}<div style={{marginTop:4}}><Cp text={m}/></div></td><td style={{padding:"7px 10px",color:C.mu}}>{e}</td></tr>)}</tbody>
        </table>
      </div>
    </Card>
    <Card>
      <Lbl text="Grab-and-go for common session types"/>
      <H3>Task-Specific Prompts</H3>
      <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:12}}>
        {TASKS.map((t,i)=><Pill key={i} label={t.label} active={tT===i} color={C.cy} onClick={()=>setTT(i)}/>)}
      </div>
      <Code text={TASKS[tT].content}/>
    </Card>
    <Card>
      <Lbl text="Ready-to-use — pick your context and copy" color={C.am}/>
      <H3>Prompt Templates</H3>
      <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:12}}>
        {TMPLS.map((t,i)=><Pill key={i} label={t.label} active={tM===i} color={C.am} onClick={()=>setTM(i)}/>)}
      </div>
      <div style={{fontSize:12,color:C.di,marginBottom:10}}>{TMPLS[tM].desc}</div>
      <Code text={TMPLS[tM].content} mh={280}/>
    </Card>
  </div>);
}

// ─── BUILD ────────────────────────────────────────────────────────────────────
const BNAV=[
  {id:"animals",label:"🐾 Animals"},{id:"8layer",label:"8 Layers"},
  {id:"meta",label:"Meta Prompt"},{id:"enhance",label:"Enhancement"},
  {id:"webapp",label:"Web App"},{id:"json",label:"JSON / Output"},
  {id:"typo",label:"Typography"},{id:"brand",label:"powerUP Brand"},
  {id:"vocab",label:"Design Vocab"},
];

function Build(){
  const[s,setS]=useState("animals");
  const[aT,setAT]=useState(0);
  const[loOpen,setLoOpen]=useState(false);
  const[layerSel,setLayerSel]=useState(0);
  const[mT,setMT]=useState("universal");
  const[eT,setET]=useState(0);
  const[showHow,setShowHow]=useState(false);
  const[wAud,setWAud]=useState(0);
  const[wFw,setWFw]=useState(0);
  const[wAe,setWAe]=useState([]);
  const[wGoal,setWGoal]=useState("");
  const[wPrompt,setWPrompt]=useState("");
  const[jT,setJT]=useState("t1");
  const[jMxSel,setJMxSel]=useState(null);
  const[jMxPrompt,setJMxPrompt]=useState("");
  const[vCat,setVCat]=useState("all");
  const[vView,setVView]=useState("terms");
  const[brandSel,setBrandSel]=useState(0);
  const[chainSel,setChainSel]=useState(null);
  const[chainPrompt,setChainPrompt]=useState("");
  const[chainTopic,setChainTopic]=useState("");
  const[animKey,setAnimKey]=useState(0);
  const switchSection=(id)=>{setS(id);setAnimKey(k=>k+1);};

  const AEST_OPTS=["dark-mode native","glassmorphism","neo-brutalism","neon accent","bento grid","kinetic typography","aurora gradients","minimal + editorial","Three.js 3D","GSAP cinematic"];
  const FWS=["Next.js + Tailwind + Framer Motion","Next.js + Tailwind + GSAP","React + Vite + Framer Motion","SvelteKit + Tailwind","Astro 4","React Native + Expo","Flutter 3"];
  const FW_NOTES=["Full-stack SSR, SEO-ready, shadcn/ui","Animation-heavy, cinematic scroll","SPA, fast dev, Radix UI","Tiny bundle, Svelte transitions","Content-first, 0kb JS default","Cross-platform mobile, Reanimated 3","Native mobile, Rive + Lottie"];

  const toggleAe=(a)=>{setWAe(p=>p.includes(a)?p.filter(x=>x!==a):[...p,a].slice(0,4));};
  const buildWP=(g=wGoal,a=wAud,f=wFw,ae=wAe)=>{
    const fw=FWS[f];const fwn=FW_NOTES[f];const auds=WEB_VARS.map(v=>v.label);
    const ael=ae.length?ae.join(" | "):"dark-mode native | neon-accent sparse | typography-first";
    return `You are a senior full-stack developer and product designer.\n\nROLE: ${auds[a]||"DEVELOPER"} perspective\nGOAL: ${g.trim()||"[Describe your app in one sentence]"}\n\nTECHNICAL STACK\n- Framework: ${fw}\n- Notes: ${fwn}\n\nFUNCTIONAL REQUIREMENTS\n- Dynamic UI components\n- Mobile-first responsive layout\n- Interactive sections with user feedback\n- Modular, reusable component architecture\n\nUI/UX DESIGN LANGUAGE\n${ae.length?ae.map(x=>"- "+x).join("\n"):"- Ultra-modern aesthetic\n- High-contrast typography\n- Smooth micro-interactions"}\n- Dark/light adaptive themes\n\nCONSTRAINTS\n- Mobile-first always\n- WCAG AA minimum\n- 60fps animation budget\n- No Lorem ipsum · No SaaS clichés\n\nAESTHETIC LOCK\n${ael}\n\nOUTPUT FORMAT\n1. Project folder structure\n2. Full source code (all files)\n3. Run instructions (3 commands)\n4. Key architectural decisions`;
  };
  const buildChainP=(ch,topic)=>{
    return ch.c.map((name,i)=>{const a=ANIMALS.find(x=>x.name===name);return `STEP ${i+1} — ${a.emoji} ${name.toUpperCase()} (${a.mode})\n${a.prompt}\n\nApply to: ${topic||"[your topic]"}`;}).join("\n\n---\n\n");
  };
  const buildJMxP=(row)=>{
    return [JSON_GLOBAL,...row.ids.map(id=>JSON_T.find(t=>t.id===id).content)].join("\n\n---\n\n");
  };

  const LAYER_SNIPS=[
    "You are a senior [role] with 10+ years of experience building [domain] products.\nYou write for practitioners, not beginners. Skip the preamble.",
    "Product: [name] — a [category] tool for [target user]\nPlatform: [web / mobile / hybrid]\nAudience: [role, skill level, goals]\nExisting stack: [tech already in use]",
    "Build a [deliverable] that [specific outcome].\nSuccess criteria:\n- [measurable criterion 1]\n- [measurable criterion 2]\n- [measurable criterion 3]",
    "- Mobile-first, tested at 375px minimum\n- WCAG AA contrast (4.5:1 text, 3:1 UI)\n- 60fps animation budget — no layout thrash\n- Bundle: <200kb JS initial load",
    "Visual style: [glassmorphism | neo-brutalism | editorial | minimal]\nTypography: [display] + [body] + [mono]\nMotion: [subtle | expressive | cinematic]\nColor mood: [dark-native | high-contrast | muted]",
    "Before generating, reason through:\n1. Information architecture — what exists and in what order?\n2. Navigation model — how does the user move?\n3. Layout grid — columns, gutters, breakpoints\n4. Interaction model — what responds to user input?\n5. Performance plan — what is lazy-loaded?",
    "OUTPUT FORMAT\nGenerate:\n1. [primary file] — complete, no TODOs\n2. [secondary file] — complete\n3. Run instructions (3 commands max)\n4. One-paragraph architectural decisions\n\nDo NOT generate: placeholder comments, lorem ipsum, mock data stubs",
    "After generating the first draft:\n1. Critique: Does each section earn its place?\n2. Refine structure: Is hierarchy readable at a glance?\n3. Refine polish: Does every interactive element have a state?\n4. Final check: Would a senior engineer approve this PR?\nOutput the final version only — no commentary.",
  ];
  const ENH_HOWTO=[
    "# SELF-REFINEMENT — How to Use\n\nAppend at end of any prompt:\n\n---\nAfter generating your first draft, do NOT show it.\n1. Critique: Is it generic? Does every section earn its place? Is it production-ready?\n2. Refine once for structure — cut anything that doesn't serve the goal.\n3. Refine once for polish — fix inconsistencies, improve specificity.\nOutput the final version only. No commentary.\n---\n\nBEST FOR: Landing page copy, design specs, API documentation, architecture decisions.",
    "# CHAIN-OF-THOUGHT — How to Use\n\nAdd BEFORE your actual request:\n\n---\nLet's think step by step. Before you answer:\n1. Identify what type of problem this is.\n2. List the key constraints and unknowns.\n3. Consider 2-3 different approaches.\n4. Select the best approach and explain why in one sentence.\nThen proceed with the solution.\n---\n\nBEST FOR: System design, multi-step flows, debugging, architecture decisions, onboarding journeys.",
    "# SELF-CONSISTENCY — How to Use\n\nInject in the middle of a creative prompt:\n\n---\nBefore committing to one solution, silently generate 6 different approaches.\nFor each, note its strongest quality and biggest weakness.\nIdentify 2-3 structural patterns that appear in the best approaches.\nMerge those patterns into one final, superior output.\nDo not show me the variants — only the final merged result.\n---\n\nBEST FOR: Hero sections, headline copy, color palettes, navigation patterns.",
    "# TWEAK PROTOCOL — How to Use\n\nTemplate:\n\n---\nRefine [SPECIFIC ELEMENT] with [SPECIFIC CHANGE].\nLock: aesthetic, color palette, layout structure, font choices.\nPreserve: component hierarchy, existing interactions, accessibility.\nDo NOT: regenerate other sections, change the tech stack.\nOutput: only the changed element with surrounding context for placement.\n---\n\nEXAMPLES:\n- Refine the CTA button copy with more urgency. Lock everything else.\n- Refine the card hover with a 3D tilt effect. Preserve layout.\n\nBEST FOR: Iterating on live designs, A/B testing copy, polishing interactions.",
    "# PROMPT DIFF — How to Use\n\nPaste both prompts:\n\n---\nCompare these two prompts. For each, score out of 10:\n- Clarity: Is the goal unambiguous?\n- Constraints: Are quality guardrails explicit?\n- Predictability: Would two AIs produce similar outputs?\n- Specificity: Is the output format fully defined?\n\nPrompt A: [paste]\nPrompt B: [paste]\n\nOutput: 1. Scores table. 2. What changed between A and B.\n3. Which performs better and why. 4. Rewrite of the weaker prompt.\n---\n\nBEST FOR: Before deploying prompts in production, refining system prompts.",
  ];

  const anim="@keyframes fadeSlideIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}@keyframes popIn{from{opacity:0;transform:scale(0.96)}to{opacity:1;transform:scale(1)}}";

  return(<div>
    <style>{anim}</style>
    <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:18,paddingBottom:14,borderBottom:`1px solid ${C.bdr}`}}>
      {BNAV.map(n=><Pill key={n.id} label={n.label} active={s===n.id} color={C.vi} onClick={()=>switchSection(n.id)}/>)}
    </div>
    <div key={animKey} style={{animation:"fadeSlideIn 0.25s cubic-bezier(0.16,1,0.3,1)"}}>

    {s==="animals"&&<div style={{display:"grid",gap:14}}>
      <Card accent={C.vi}>
        <Lbl text='Trigger by name: "Apply Owl Mode" / "Think like a Beaver"' color={C.vi}/>
        <H3>Animal Thinking Modes</H3>
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:14}}>
          {ANIMALS.map((a,i)=><button key={i} onClick={()=>setAT(i)} style={{background:aT===i?`${AC[a.name]}18`:"transparent",border:`1px solid ${aT===i?AC[a.name]+"55":C.bdr}`,color:aT===i?AC[a.name]:C.di,borderRadius:10,padding:"7px 13px",cursor:"pointer",fontSize:13,transition:"all 0.2s",transform:aT===i?"scale(1.03)":"scale(1)"}}>{a.emoji} {a.name}</button>)}
        </div>
        <div style={{fontSize:10,color:AC[ANIMALS[aT].name],fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:6}}>{ANIMALS[aT].mode.toUpperCase()}</div>
        <Code text={ANIMALS[aT].prompt}/>
      </Card>
      <Card>
        <Lbl text="Click a chain → generate combined prompt below" color={C.am}/>
        <H3>Mode Chains</H3>
        <div style={{marginBottom:10}}>
          <Inp label="Topic (optional — personalizes the prompt)" value={chainTopic} onChange={setChainTopic} ph="e.g. Launch a SaaS product, Design an onboarding flow"/>
        </div>
        <div style={{display:"grid",gap:8,marginBottom:chainPrompt?14:0}}>
          {CHAINS.map((ch,i)=><div key={i} onClick={()=>{setChainSel(i);setChainPrompt(buildChainP(ch,chainTopic));}} style={{background:chainSel===i?`${C.vi}12`:C.bg,border:`1px solid ${chainSel===i?C.vi+"55":C.bdr}`,borderRadius:10,padding:"10px 14px",cursor:"pointer",transition:"all 0.18s",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8,transform:chainSel===i?"translateX(3px)":"none"}}>
            <span style={{color:C.tx,fontWeight:600,fontSize:13}}>{ch.goal}</span>
            <span style={{fontFamily:C.mn,fontSize:15,color:C.am}}>{ch.c.map(n=>AE[n]).join(" → ")}</span>
            <span style={{fontSize:11,color:C.di}}>{ch.best}</span>
          </div>)}
        </div>
        {chainPrompt&&<div style={{animation:"popIn 0.2s ease-out"}}>
          <div style={{fontSize:10,color:C.gn,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>✓ COMBINED CHAIN PROMPT</div>
          <Code text={chainPrompt} mh={300}/>
        </div>}
      </Card>
    </div>}

    {s==="8layer"&&<div style={{display:"grid",gap:14}}>
      <Card accent={C.vi}>
        <Lbl text="Universal structure — click each layer to get its copy-ready snippet" color={C.vi}/>
        <H3>8-Layer Prompt Architecture</H3>
        <div style={{fontFamily:C.mn,fontSize:12,color:C.mu,marginBottom:16,background:C.bg,borderRadius:8,padding:"10px 14px",letterSpacing:"0.04em"}}>ROLE → CONTEXT → OBJECTIVE → CONSTRAINTS → AESTHETIC → PLANNING → OUTPUT → REFINEMENT</div>
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:14}}>
          {LAYERS.map((l,i)=><Pill key={l.n} label={`${l.n} ${l.name}`} active={layerSel===i} color={C.vi} onClick={()=>setLayerSel(i)}/>)}
        </div>
        <div key={layerSel} style={{background:C.bg,border:`1px solid ${C.vi}30`,borderRadius:10,padding:"14px",marginBottom:14,animation:"popIn 0.18s ease-out"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
            <div>
              <div style={{fontSize:10,color:C.vi,fontFamily:C.mn,marginBottom:3}}>LAYER {LAYERS[layerSel].n} — {LAYERS[layerSel].name.toUpperCase()}</div>
              <div style={{fontWeight:600,color:C.tx,marginBottom:2}}>{LAYERS[layerSel].pur}</div>
              <div style={{fontSize:11,color:C.rd,fontFamily:C.mn}}>Missing → {LAYERS[layerSel].miss}</div>
            </div>
            <Cp text={LAYER_SNIPS[layerSel]} sm={false} label="COPY SNIPPET"/>
          </div>
          <Code text={LAYER_SNIPS[layerSel]}/>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:8,marginBottom:16}}>
          {LAYERS.map((l,i)=><div key={l.n} onClick={()=>setLayerSel(i)} style={{background:layerSel===i?`${C.vi}12`:C.bg,border:`1px solid ${layerSel===i?C.vi+"44":C.bdr}`,borderRadius:9,padding:"10px 12px",cursor:"pointer",transition:"all 0.15s"}}>
            <div style={{fontSize:10,color:C.vi,fontFamily:C.mn,marginBottom:3}}>LAYER {l.n}</div>
            <div style={{fontWeight:700,color:C.tx,fontSize:13,marginBottom:2}}>{l.name}</div>
            <div style={{fontSize:11,color:C.mu}}>{l.pur}</div>
          </div>)}
        </div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
          <span style={{fontSize:12,color:C.di}}>Complete 8-Layer Template</span>
          <div style={{display:"flex",gap:6}}>
            <button onClick={()=>setLoOpen(o=>!o)} style={{background:"transparent",border:`1px solid ${C.bdr}`,color:C.mu,borderRadius:6,padding:"4px 12px",fontSize:11,fontFamily:C.mn,cursor:"pointer"}}>{loOpen?"HIDE":"SHOW"}</button>
            {loOpen&&<Cp text={LAYER_TPL}/>}
          </div>
        </div>
        {loOpen&&<Code text={LAYER_TPL} mh={300}/>}
      </Card>
    </div>}

    {s==="meta"&&<Card accent={C.vi}>
      <Lbl text="Makes AI structure any vague concept before generating" color={C.vi}/>
      <H3>Meta Prompting Framework</H3>
      <div style={{display:"flex",gap:6,marginBottom:14,flexWrap:"wrap"}}>
        {[["universal","Universal"],["mobile","📱 Mobile"],["web","🌐 Web"]].map(([id,lb])=><Pill key={id} label={lb} active={mT===id} color={C.vi} onClick={()=>setMT(id)}/>)}
      </div>
      <Code text={META[mT]}/>
      {mT!=="universal"&&<div style={{marginTop:16,animation:"fadeSlideIn 0.2s ease-out"}}>
        <div style={{fontSize:10,color:C.am,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:10}}>MOBILE vs WEB COMPARISON</div>
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
            <thead><tr>{["Aspect","Mobile","Web"].map(h=><th key={h} style={{textAlign:"left",padding:"6px 10px",color:C.di,fontSize:10,fontFamily:C.mn,borderBottom:`1px solid ${C.bdr}`}}>{h}</th>)}</tr></thead>
            <tbody>{[["Navigation","Bottom tabs, gestures","Sidebar / top nav / hybrid"],["Touch","44px targets minimum","Not applicable (pointer:fine)"],["Interactions","Pinch, swipe, long-press","Hover states, parallax scroll"],["Constraints","Battery, safe-areas, offline","SEO, Core Web Vitals"],["Stack","React Native + Expo / Flutter","Next.js + Tailwind / SvelteKit"],["Animation","Reanimated 3, haptics-aware","GSAP ScrollTrigger / Framer Motion"]].map(([a,m,w],i)=><tr key={i} style={{borderBottom:`1px solid #ffffff06`}}><td style={{padding:"8px 10px",color:C.cy,fontFamily:C.mn,fontSize:11}}>{a}</td><td style={{padding:"8px 10px",color:C.mu}}>{m}</td><td style={{padding:"8px 10px",color:C.mu}}>{w}</td></tr>)}</tbody>
          </table>
        </div>
      </div>}
    </Card>}

    {s==="enhance"&&<Card>
      <Lbl text="Apply to any prompt for higher-quality output"/>
      <H3>Enhancement Protocols</H3>
      <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:12}}>
        {ENH.map((e,i)=><Pill key={i} label={e.label} active={eT===i} color={C.mg} onClick={()=>setET(i)}/>)}
      </div>
      <div style={{display:"flex",gap:6,marginBottom:12}}>
        <Pill label="Prompt Snippet" active={!showHow} color={C.vi} onClick={()=>setShowHow(false)}/>
        <Pill label="📖 How to Use" active={showHow} color={C.am} onClick={()=>setShowHow(true)}/>
      </div>
      <div key={`${eT}-${showHow}`} style={{animation:"popIn 0.18s ease-out"}}>
        <Code text={showHow?ENH_HOWTO[eT]:ENH[eT].content} mh={380}/>
      </div>
    </Card>}

    {s==="webapp"&&<div style={{display:"grid",gap:14}}>
      <Card accent={C.cy}>
        <Lbl text="Configure your app — prompt updates live as you select" color={C.cy}/>
        <H3>Web App Prompt Generator</H3>
        <Inp label="YOUR APP GOAL" value={wGoal} onChange={g=>{setWGoal(g);setWPrompt(buildWP(g,wAud,wFw,wAe));}} ph="e.g. A project management tool for remote teams"/>
        <div style={{marginBottom:12}}>
          <div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>AUDIENCE</div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            {WEB_VARS.map((v,i)=><Pill key={v.id} label={v.label} active={wAud===i} color={C.cy} onClick={()=>{setWAud(i);setWPrompt(buildWP(wGoal,i,wFw,wAe));}}/>)}
          </div>
          <div style={{fontSize:11,color:C.di,marginTop:6}}>{WEB_VARS[wAud]?.desc}</div>
        </div>
        <div style={{marginBottom:12}}>
          <div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>FRAMEWORK</div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            {FWS.map((fw,i)=><Pill key={i} label={fw.split(" + ")[0]+" + "+fw.split(" + ")[1]} active={wFw===i} color={C.vi} onClick={()=>{setWFw(i);setWPrompt(buildWP(wGoal,wAud,i,wAe));}}/>)}
          </div>
          <div style={{fontSize:11,color:C.di,marginTop:6}}>{FW_NOTES[wFw]}</div>
        </div>
        <div style={{marginBottom:14}}>
          <div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>AESTHETIC KEYWORDS (pick up to 4)</div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            {AEST_OPTS.map(a=>{const sel=wAe.includes(a);return <button key={a} onClick={()=>{const nae=sel?wAe.filter(x=>x!==a):[...wAe,a].slice(0,4);setWAe(nae);setWPrompt(buildWP(wGoal,wAud,wFw,nae));}} style={{background:sel?`${C.mg}18`:"transparent",border:`1px solid ${sel?C.mg+"55":C.bdr}`,color:sel?C.mg:C.di,borderRadius:20,padding:"4px 11px",fontSize:11,fontFamily:C.mn,cursor:"pointer",transition:"all 0.15s",transform:sel?"scale(1.04)":"none"}}>{a}</button>;})}
          </div>
        </div>
        <div style={{fontSize:10,color:C.gn,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>↓ LIVE PROMPT — updates as you configure above</div>
        <Code text={wPrompt||buildWP("",0,0,[])} mh={260}/>
      </Card>
      <Card>
        <Lbl text="Always define these three before generating" color={C.bl}/>
        <H3>The Three Layers Rule</H3>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
          {[["FUNCTION","What does the app DO?",C.cy],["DESIGN","What does it LOOK & FEEL like?",C.vi],["TECHNOLOGY","What STACK runs it?",C.am]].map(([l,q,col])=><div key={l} style={{background:C.bg,border:`1px solid ${col}22`,borderRadius:10,padding:"14px",textAlign:"center"}}><div style={{fontSize:10,color:col,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:6}}>{l}</div><div style={{fontSize:12,color:C.mu}}>{q}</div></div>)}
        </div>
      </Card>
      <Card>
        <Lbl text="Dolphin Mode — 10 creative UI concepts to spark ideas" color={C.bl}/>
        <H3>Creative UI Concepts</H3>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(195px,1fr))",gap:8}}>
          {DOLPHIN_C.map((c,i)=><div key={i} style={{background:C.bg,border:`1px solid ${C.bdr}`,borderRadius:8,padding:"10px 12px",display:"flex",gap:10}}>
            <span style={{fontSize:10,color:C.bl,fontFamily:C.mn,minWidth:20,marginTop:1}}>#{String(i+1).padStart(2,"00")}</span>
            <div style={{flex:1}}><span style={{fontSize:12,color:C.mu,lineHeight:1.5}}>{c}</span></div>
            <Cp text={`Dolphin mode creative UI concept: ${c}`}/>
          </div>)}
        </div>
      </Card>
    </div>}

    {s==="json"&&<div style={{display:"grid",gap:14}}>
      <Card accent={C.cy}>
        <Lbl text="GLOBAL RULE — always append when requesting JSON" color={C.cy}/>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}><H3>Structured Output / JSON</H3><Cp text={JSON_GLOBAL} sm={false}/></div>
        <Code text={JSON_GLOBAL}/>
      </Card>
      <Card>
        <Lbl text="4 techniques — use in combination"/>
        <H3>Techniques</H3>
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:14}}>
          {JSON_T.map(t=><Pill key={t.id} label={t.label} active={jT===t.id} color={t.color} onClick={()=>setJT(t.id)}/>)}
        </div>
        {JSON_T.filter(t=>t.id===jT).map(t=><div key={t.id} style={{animation:"popIn 0.18s ease-out"}}>
          <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:10}}>
            <span style={{fontSize:10,background:`${t.color}18`,color:t.color,border:`1px solid ${t.color}30`,borderRadius:20,padding:"2px 10px",fontFamily:C.mn}}>{t.badge}</span>
            <span style={{fontSize:11,color:C.di}}>Use when: {t.when}</span>
          </div>
          <Code text={t.content}/>
        </div>)}
        <div style={{marginTop:16}}>
          <div style={{fontSize:10,color:C.am,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>DECISION MATRIX — click a row to generate its combined prompt</div>
          <div style={{display:"grid",gap:6,marginBottom:jMxPrompt?14:0}}>
            {JSON_MX.map((r,i)=><div key={i} onClick={()=>{setJMxSel(i);setJMxPrompt(buildJMxP(r));}} style={{display:"flex",justifyContent:"space-between",background:jMxSel===i?`${C.cy}10`:C.bg,border:`1px solid ${jMxSel===i?C.cy+"44":C.bdr}`,borderRadius:8,padding:"9px 12px",cursor:"pointer",transition:"all 0.18s",gap:12,transform:jMxSel===i?"translateX(3px)":"none"}}>
              <span style={{fontSize:12,color:C.mu,flex:1}}>{r.sit}</span>
              <span style={{fontSize:12,color:C.cy,fontFamily:C.mn,whiteSpace:"nowrap"}}>{r.use}</span>
            </div>)}
          </div>
          {jMxPrompt&&<div style={{animation:"popIn 0.2s ease-out"}}>
            <div style={{fontSize:10,color:C.gn,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>✓ COMBINED JSON PROMPT</div>
            <Code text={jMxPrompt} mh={320}/>
          </div>}
        </div>
      </Card>
    </div>}

    {s==="typo"&&<div style={{display:"grid",gap:14}}>
      <Card>
        <Lbl text="Display + Body + Mono — Google Fonts compatible"/>
        <H3>Typography Pairings</H3>
        <div style={{display:"grid",gap:8}}>
          {TYPO.map((t,i)=><div key={i} style={{background:C.bg,border:`1px solid ${C.bdr}`,borderRadius:9,padding:"12px 14px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8,transition:"border-color 0.15s"}}>
            <div><span style={{fontWeight:700,color:C.tx}}>{t.d}</span><span style={{color:C.di,fontSize:12,marginLeft:6}}>+ {t.m}</span></div>
            <div style={{display:"flex",gap:8,alignItems:"center"}}>
              <span style={{fontSize:11,color:C.di}}>{t.b}</span>
              <Cp text={`Typography system: Display: ${t.d} · Mono: ${t.m} · Best for: ${t.b}`}/>
            </div>
          </div>)}
        </div>
      </Card>
      <Card>
        <Lbl text="Context-specific font combinations"/>
        <H3>Infographic Typography</H3>
        <div style={{display:"grid",gap:8}}>
          {TYPO_I.map((t,i)=><div key={i} style={{background:C.bg,border:`1px solid ${C.bdr}`,borderRadius:9,padding:"12px 14px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
            <div style={{flex:1}}>
              <div style={{fontSize:10,color:C.vi,fontFamily:C.mn,marginBottom:4}}>{t.u.toUpperCase()}</div>
              <div style={{fontSize:12,color:C.mu}}>{t.c}</div>
            </div>
            <Cp text={`${t.u}: ${t.c}`}/>
          </div>)}
        </div>
      </Card>
    </div>}

    {s==="brand"&&<div style={{display:"grid",gap:14}}>
      <Card>
        <Lbl text="Complete brand system prompts — click to select, copy to use" color={C.mg}/>
        <H3>Brand Systems</H3>
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:14}}>
          {BRANDS.map((b,i)=><button key={b.id} onClick={()=>{setBrandSel(i);}} style={{background:brandSel===i?`${b.col}18`:"transparent",border:`1px solid ${brandSel===i?b.col+"55":C.bdr}`,color:brandSel===i?b.col:C.di,borderRadius:20,padding:"5px 12px",fontSize:11,fontFamily:C.mn,cursor:"pointer",transition:"all 0.18s",transform:brandSel===i?"scale(1.04)":"none"}}>{b.label}</button>)}
        </div>
        <div style={{fontSize:11,color:C.di,marginBottom:12,fontStyle:"italic"}}>Ideal use-case: {BRANDS[brandSel].uc}</div>
        <div key={brandSel} style={{animation:"popIn 0.2s ease-out"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
            <span style={{fontSize:12,color:BRANDS[brandSel].col,fontFamily:C.mn,fontWeight:600,letterSpacing:"0.08em"}}>{BRANDS[brandSel].label.toUpperCase()}</span>
            <Cp text={BRANDS[brandSel].prompt} sm={false}/>
          </div>
          <Code text={BRANDS[brandSel].prompt} mh={420}/>
        </div>
      </Card>
    </div>}

    {s==="vocab"&&<div style={{display:"grid",gap:14}}>
      <Card>
        <Lbl text="Use exact terms to control AI visual output — includes misconceptions"/>
        <H3>Design Vocabulary</H3>
        <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:10}}>
          {["all","core","motion","adv"].map(c=><Pill key={c} label={c==="adv"?"ADVANCED":c.toUpperCase()} active={vCat===c} color={C.cy} onClick={()=>setVCat(c)}/>)}
        </div>
        <div style={{display:"flex",gap:6,marginBottom:14}}>
          <Pill label="Terms + Copy" active={vView==="terms"} color={C.vi} onClick={()=>setVView("terms")}/>
          <Pill label="vs Misconceptions" active={vView==="wrong"} color={C.rd} onClick={()=>setVView("wrong")}/>
          <Pill label="Synergy Combos" active={vView==="combos"} color={C.mg} onClick={()=>setVView("combos")}/>
        </div>
        {vView!=="combos"&&<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(250px,1fr))",gap:8}}>
          {VOCAB.filter(v=>vCat==="all"||v.cat===vCat).map((v,i)=><div key={i} style={{background:C.bg,border:`1px solid ${C.bdr}`,borderRadius:9,padding:"11px 13px",transition:"border-color 0.15s"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8,marginBottom:5}}>
              <div style={{fontSize:12,color:C.cy,fontFamily:C.mn,fontWeight:600}}>{v.t}</div>
              <Cp text={vView==="wrong"?`MISCONCEPTION about "${v.t}": ${v.wrong}\n\nCORRECT: ${v.d}`:`Use "${v.t}" in your prompt to get: ${v.d}`}/>
            </div>
            {vView==="terms"?<div style={{fontSize:11,color:C.mu,lineHeight:1.55}}>{v.d}</div>
            :<div><div style={{fontSize:11,color:C.rd,lineHeight:1.5,marginBottom:4}}>❌ {v.wrong}</div><div style={{fontSize:11,color:C.gn,lineHeight:1.5}}>✅ {v.d}</div></div>}
          </div>)}
        </div>}
        {vView==="combos"&&<div style={{display:"grid",gap:8}}>
          {COMBOS.map((d,i)=><div key={i} style={{background:C.bg,border:`1px solid ${C.bdr}`,borderRadius:9,padding:"11px 14px",transition:"border-color 0.15s"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:8,marginBottom:4}}>
              <span style={{fontWeight:700,color:C.tx,fontSize:13}}>{d.combo}</span>
              <div style={{display:"flex",gap:8,alignItems:"center"}}>
                <span style={{fontSize:10,color:C.vi,fontFamily:C.mn}}>{d.psych}</span>
                <Cp text={`Design combo "${d.combo}": ${d.els}. Best for: ${d.best}. Psychological effect: ${d.psych}.`}/>
              </div>
            </div>
            <div style={{fontSize:11,color:C.mu}}>{d.els}</div>
            <div style={{fontSize:10,color:C.di,marginTop:3}}>Best for: {d.best}</div>
          </div>)}
        </div>}
      </Card>
    </div>}

    </div>
  </div>);
}


// ─── VALIDATE ─────────────────────────────────────────────────────────────────
function Validate(){
  const[chk,setChk]=useState({});
  const[sc,setSc]=useState({Clarity:5,Structure:5,Constraints:5,Predictability:5});
  const avg=(Object.values(sc).reduce((a,b)=>a+b,0)/4).toFixed(1);
  const grade=SSCALE.find(s=>{const[lo,hi]=s.r.split("–").map(Number);return avg>=lo&&avg<=hi;})||SSCALE[SSCALE.length-1];
  const total=CHECKS.reduce((a,g)=>a+g.items.length,0);
  const done=Object.values(chk).filter(Boolean).length;
  return(<div style={{display:"grid",gap:14}}>
    <Card>
      <Lbl text="6 checks to run before generating"/>
      <H3>Prompt Lint Rules</H3>
      <div style={{display:"grid",gap:8,marginBottom:18}}>
        {LINT.map(r=><div key={r.id} style={{background:C.bg,border:`1px solid ${C.bdr}`,borderRadius:9,padding:"10px 13px",display:"flex",gap:10}}>
          <span style={{fontSize:15}}>{r.auto?"✅":"⚠️"}</span>
          <div><div style={{fontSize:10,color:C.cy,fontFamily:C.mn,marginBottom:2}}>{r.id}</div><div style={{fontSize:13,color:C.tx,marginBottom:2}}>{r.check}</div><div style={{fontSize:11,color:C.di}}>{r.auto?"Autofix: ":"Requires: "}{r.fix}</div></div>
        </div>)}
      </div>
      <div style={{fontSize:10,color:C.am,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>WORD SWAPS</div>
      <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
        <thead><tr>{["❌ Avoid","✅ Replace With"].map(h=><th key={h} style={{textAlign:"left",padding:"6px 10px",color:C.di,fontSize:10,fontFamily:C.mn,borderBottom:`1px solid ${C.bdr}`}}>{h}</th>)}</tr></thead>
        <tbody>{SWAPS.map(([b,g],i)=><tr key={i} style={{borderBottom:`1px solid #ffffff06`}}><td style={{padding:"8px 10px",color:C.rd,fontFamily:C.mn}}>{b}</td><td style={{padding:"8px 10px",color:C.gn,fontFamily:C.mn}}>{g}</td></tr>)}</tbody>
      </table>
    </Card>
    <Card>
      <Lbl text="Run before submitting any production prompt"/>
      <H3>Quality Checklist</H3>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:16}}>
        <div style={{flex:1,background:C.bg,borderRadius:999,height:5,overflow:"hidden"}}><div style={{width:`${(done/total)*100}%`,background:C.cy,height:"100%",borderRadius:999,transition:"width 0.3s"}}/></div>
        <span style={{fontSize:12,fontFamily:C.mn,color:done===total?C.gn:C.mu}}>{done}/{total}</span>
      </div>
      <div style={{display:"grid",gap:14}}>
        {CHECKS.map((g,gi)=><div key={gi}>
          <div style={{fontSize:10,color:C.am,fontFamily:C.mn,letterSpacing:"0.12em",marginBottom:8}}>{g.lbl}</div>
          <div style={{display:"grid",gap:6}}>
            {g.items.map((item,ii)=>{const k=`${gi}-${ii}`;return(<label key={ii} style={{display:"flex",gap:10,cursor:"pointer"}}>
              <input type="checkbox" checked={!!chk[k]} onChange={()=>setChk(p=>({...p,[k]:!p[k]}))} style={{marginTop:2,accentColor:C.cy}}/>
              <span style={{fontSize:13,color:chk[k]?C.di:C.tx,textDecoration:chk[k]?"line-through":"none",lineHeight:1.5}}>{item}</span>
            </label>);})}
          </div>
        </div>)}
      </div>
    </Card>
    <Card>
      <Lbl text="A/B test and compare prompt variants"/>
      <H3>Prompt Scoring</H3>
      <div style={{display:"grid",gap:12,marginBottom:18}}>
        {SDIMS.map(d=><div key={d.name}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span style={{fontSize:13,fontWeight:600,color:C.tx}}>{d.name}</span><span style={{fontSize:13,fontFamily:C.mn,color:C.cy}}>{sc[d.name]}/10</span></div>
          <div style={{fontSize:11,color:C.di,marginBottom:4}}>{d.what}</div>
          <input type="range" min={1} max={10} value={sc[d.name]} onChange={e=>setSc(p=>({...p,[d.name]:Number(e.target.value)}))} style={{width:"100%",accentColor:C.cy}}/>
        </div>)}
      </div>
      <div style={{background:C.bg,border:`1px solid ${grade.col}33`,borderRadius:10,padding:"14px 18px",display:"flex",alignItems:"center",gap:18,marginBottom:14}}>
        <div style={{fontSize:36,fontWeight:800,fontFamily:C.mn,color:grade.col}}>{avg}</div>
        <div><div style={{fontWeight:700,color:C.tx,marginBottom:2}}>{grade.level}</div><div style={{fontSize:12,color:C.mu}}>{grade.action}</div></div>
      </div>
      <div style={{display:"grid",gap:5}}>
        {SSCALE.map((s,i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 10px",borderRadius:6,background:grade===s?`${s.col}10`:"transparent",border:`1px solid ${grade===s?s.col+"44":"transparent"}`}}>
          <span style={{fontFamily:C.mn,fontSize:12,color:s.col,minWidth:36}}>{s.r}</span>
          <span style={{fontSize:12,color:C.mu,flex:1,paddingLeft:10}}>{s.level}</span>
          <span style={{fontSize:11,color:C.di}}>{s.action}</span>
        </div>)}
      </div>
    </Card>
  </div>);
}

// ─── PLAYBOOK ─────────────────────────────────────────────────────────────────
function Playbook(){
  const[cat,setCat]=useState("All");
  const[q,setQ]=useState("");
  const[open,setOpen]=useState(null);
  const cats=["All",...Array.from(new Set(WF.map(w=>w.cat)))];
  const list=WF.filter(w=>(cat==="All"||w.cat===cat)&&(!q||w.title.toLowerCase().includes(q.toLowerCase())||w.purpose.toLowerCase().includes(q.toLowerCase())));
  const mk=w=>w.steps.map((s,i)=>`Step ${i+1} (${AE[s.a]} ${s.a}):\n${s.items.map(x=>`- ${x}`).join("\n")}`).join("\n\n")+`\n\nFinal Output: ${w.out}`;
  return(<div>
    <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search workflows…" style={{width:"100%",boxSizing:"border-box",background:C.sur,border:`1px solid ${C.bdr}`,borderRadius:8,padding:"10px 14px",color:C.tx,fontSize:13,outline:"none",marginBottom:12}}/>
    <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:16}}>
      {cats.map(c=><Pill key={c} label={c==="All"?`All (${WF.length})`:c} active={cat===c} color={C.am} onClick={()=>setCat(c)}/>)}
    </div>
    <div style={{display:"grid",gap:8}}>
      {list.map(w=>{const io=open===w.id;return(<div key={w.id} style={{background:C.sur,border:`1px solid ${io?C.bdrH:C.bdr}`,borderRadius:12,overflow:"hidden"}}>
        <button onClick={()=>setOpen(io?null:w.id)} style={{width:"100%",background:"none",border:"none",padding:"13px 17px",cursor:"pointer",textAlign:"left",display:"flex",alignItems:"center",gap:12}}>
          <span style={{fontFamily:C.mn,fontSize:10,color:C.cy,minWidth:24,opacity:0.6}}>#{String(w.id).padStart(2,"0")}</span>
          <div style={{flex:1}}><div style={{fontWeight:700,color:C.tx,fontSize:13,marginBottom:1}}>{w.title}</div><div style={{fontSize:11,color:C.di}}>{w.purpose} · {w.best}</div></div>
          <div style={{display:"flex",gap:3}}>{w.chain.map((a,i)=><span key={i} style={{fontSize:14}}>{AE[a]}</span>)}</div>
          <span style={{color:C.fa,fontSize:13,marginLeft:4}}>{io?"▲":"▼"}</span>
        </button>
        {io&&<div style={{borderTop:`1px solid ${C.bdr}`,padding:"0 17px 17px"}}>
          <div style={{display:"flex",gap:5,flexWrap:"wrap",padding:"11px 0"}}>
            {w.chain.map((a,i)=><span key={i}><span style={{background:`${AC[a]}12`,border:`1px solid ${AC[a]}28`,color:AC[a],borderRadius:20,padding:"3px 9px",fontSize:11,fontFamily:C.mn}}>{AE[a]} {a}</span>{i<w.chain.length-1&&<span style={{color:C.fa,margin:"0 3px",fontSize:11}}>→</span>}</span>)}
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(195px,1fr))",gap:9,marginBottom:12}}>
            {w.steps.map((s,i)=><div key={i} style={{background:C.bg,border:`1px solid ${AC[s.a]}20`,borderRadius:9,padding:"10px 12px"}}>
              <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:6}}><span style={{fontSize:14}}>{AE[s.a]}</span><div><div style={{fontSize:9,color:AC[s.a],fontFamily:C.mn}}>STEP {i+1}</div><div style={{fontSize:12,fontWeight:600,color:C.tx}}>{s.t}</div></div></div>
              <ul style={{margin:0,padding:"0 0 0 12px"}}>{s.items.map((item,j)=><li key={j} style={{fontSize:11,color:C.mu,lineHeight:1.6}}>{item}</li>)}</ul>
            </div>)}
          </div>
          <div style={{background:C.bg,border:`1px solid ${C.gn}20`,borderRadius:8,padding:"9px 12px",display:"flex",gap:10,marginBottom:11}}><span>✅</span><div><div style={{fontSize:10,color:C.gn,fontFamily:C.mn,marginBottom:2}}>FINAL OUTPUT</div><div style={{fontSize:12,color:C.tx}}>{w.out}</div></div></div>
          <Cp text={mk(w)} sm={false}/>
        </div>}
      </div>);})}
      {list.length===0&&<div style={{textAlign:"center",color:C.fa,padding:"36px 0",fontFamily:C.mn,fontSize:12}}>No workflows match "{q}"</div>}
    </div>
  </div>);
}

// ─── BUILDER ──────────────────────────────────────────────────────────────────
function WFBuilder(){
  const[chain,setChain]=useState([]);
  const[goal,setGoal]=useState("");
  const[outL,setOutL]=useState("");
  const[res,setRes]=useState("");
  const[hist,setHist]=useState([]);
  const[showH,setShowH]=useState(false);
  const[expH,setExpH]=useState(null);
  const add=n=>{if(chain.length<6){setChain(p=>[...p,n]);setRes("");}};
  const rm=i=>{setChain(p=>p.filter((_,j)=>j!==i));setRes("");};
  const mv=(i,d)=>{const n=[...chain];const t=i+d;if(t<0||t>=n.length)return;[n[i],n[t]]=[n[t],n[i]];setChain(n);setRes("");};
  const gen=()=>{
    if(!chain.length)return;
    const lines=chain.map((nm,i)=>{const a=ANIMALS.find(x=>x.name===nm);return `Step ${i+1} (${a.emoji} ${nm} — ${a.mode}):\n${a.prompt}`;}).join("\n\n");
    const p=`${goal.trim()?`GOAL: ${goal.trim()}\n\n`:""}${lines}${outL.trim()?`\n\nFinal Output: ${outL.trim()}`:""}`;
    setRes(p);
    setHist(h=>[{id:Date.now(),goal:goal.trim()||"Untitled",chain:[...chain],outL:outL.trim(),prompt:p,time:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})},...h].slice(0,10));
  };
  const load=e=>{setChain(e.chain);setGoal(e.goal==="Untitled"?"":e.goal);setOutL(e.outL);setRes(e.prompt);setShowH(false);};
  const reset=()=>{setChain([]);setGoal("");setOutL("");setRes("");};
  return(<Card sx={{marginBottom:14}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16}}>
      <div><Lbl text="Compose animal mode chains → generate prompt" color={C.mg}/><H3>Workflow Builder</H3></div>
      {hist.length>0&&<button onClick={()=>setShowH(h=>!h)} style={{background:showH?`${C.am}15`:"transparent",border:`1px solid ${showH?C.am+"55":C.bdr}`,color:showH?C.am:C.di,borderRadius:8,padding:"6px 11px",fontSize:11,fontFamily:C.mn,cursor:"pointer",flexShrink:0}}>🕐 HISTORY ({hist.length})</button>}
    </div>
    {showH&&<div style={{background:C.bg,border:`1px solid ${C.am}22`,borderRadius:10,padding:13,marginBottom:16}}>
      <div style={{fontSize:10,color:C.am,fontFamily:C.mn,letterSpacing:"0.12em",marginBottom:10}}>RECENT PROMPTS</div>
      <div style={{display:"grid",gap:6}}>
        {hist.map(e=><div key={e.id} style={{background:C.sur,border:`1px solid ${C.bdr}`,borderRadius:8,overflow:"hidden"}}>
          <div style={{display:"flex",alignItems:"center",gap:10,padding:"8px 12px"}}>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:12,fontWeight:600,color:C.tx,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{e.goal}</div>
              <div style={{fontSize:11,color:C.di,marginTop:1}}>{e.chain.map(n=>AE[n]).join(" → ")} · {e.time}</div>
            </div>
            <div style={{display:"flex",gap:4,flexShrink:0}}>
              <button onClick={()=>setExpH(expH===e.id?null:e.id)} style={{background:"transparent",border:`1px solid ${C.bdr}`,color:C.mu,borderRadius:6,padding:"3px 8px",fontSize:10,fontFamily:C.mn,cursor:"pointer"}}>{expH===e.id?"HIDE":"VIEW"}</button>
              <button onClick={()=>load(e)} style={{background:`${C.cy}10`,border:`1px solid ${C.cy}28`,color:C.cy,borderRadius:6,padding:"3px 8px",fontSize:10,fontFamily:C.mn,cursor:"pointer"}}>LOAD</button>
              <Cp text={e.prompt}/>
              <button onClick={()=>setHist(p=>p.filter(x=>x.id!==e.id))} style={{background:"transparent",border:`1px solid ${C.rd}22`,color:C.rd,borderRadius:6,width:24,height:24,cursor:"pointer",fontSize:12,display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
            </div>
          </div>
          {expH===e.id&&<div style={{borderTop:`1px solid ${C.bdr}`,padding:"9px 12px"}}><pre style={{margin:0,fontSize:11,color:C.mu,fontFamily:C.mn,whiteSpace:"pre-wrap",maxHeight:150,overflowY:"auto"}}>{e.prompt}</pre></div>}
        </div>)}
      </div>
    </div>}
    <Inp label="YOUR GOAL (optional)" value={goal} onChange={setGoal} ph="e.g. Build a SaaS onboarding flow for enterprise users"/>
    <div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>SELECT MODES — CLICK TO ADD (max 6)</div>
    <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:16}}>
      {ANIMALS.map(a=><button key={a.name} onClick={()=>add(a.name)} disabled={chain.length>=6} style={{background:`${AC[a.name]}10`,border:`1px solid ${AC[a.name]}28`,color:AC[a.name],borderRadius:10,padding:"7px 12px",cursor:chain.length>=6?"not-allowed":"pointer",opacity:chain.length>=6?0.4:1,fontSize:12,display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
        <span style={{fontSize:20}}>{a.emoji}</span>
        <span style={{fontSize:10,fontFamily:C.mn}}>{a.name}</span>
      </button>)}
    </div>
    <div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>YOUR CHAIN {chain.length>0&&`— ${chain.length} step${chain.length>1?"s":""}`}</div>
    {chain.length===0?<div style={{background:C.bg,border:`1px dashed ${C.bdr}`,borderRadius:10,padding:"20px",textAlign:"center",marginBottom:13}}><div style={{fontSize:20,marginBottom:5}}>⬆</div><div style={{fontSize:12,color:C.fa,fontFamily:C.mn}}>Click animals above to build your chain</div></div>
    :<div style={{display:"flex",flexDirection:"column",gap:6,marginBottom:13}}>
      {chain.map((nm,idx)=>{const a=ANIMALS.find(x=>x.name===nm);const col=AC[nm];return(<div key={idx} style={{background:C.bg,border:`1px solid ${col}28`,borderRadius:9,padding:"9px 12px",display:"flex",alignItems:"center",gap:10}}>
        <span style={{fontSize:10,color:C.fa,fontFamily:C.mn,minWidth:20}}>{String(idx+1).padStart(2,"0")}</span>
        <span style={{fontSize:17}}>{AE[nm]}</span>
        <div style={{flex:1}}><span style={{fontWeight:700,color:col,fontSize:13}}>{nm}</span><span style={{fontSize:11,color:C.di,marginLeft:8}}>{a.mode}</span></div>
        <div style={{display:"flex",gap:3}}>
          <button onClick={()=>mv(idx,-1)} disabled={idx===0} style={{background:"none",border:`1px solid ${C.bdr}`,color:C.di,borderRadius:5,width:24,height:24,cursor:idx===0?"default":"pointer",opacity:idx===0?0.3:1,fontSize:11}}>↑</button>
          <button onClick={()=>mv(idx,1)} disabled={idx===chain.length-1} style={{background:"none",border:`1px solid ${C.bdr}`,color:C.di,borderRadius:5,width:24,height:24,cursor:idx===chain.length-1?"default":"pointer",opacity:idx===chain.length-1?0.3:1,fontSize:11}}>↓</button>
          <button onClick={()=>rm(idx)} style={{background:"none",border:`1px solid ${C.rd}33`,color:C.rd,borderRadius:5,width:24,height:24,cursor:"pointer",fontSize:11}}>×</button>
        </div>
      </div>);})}
      {chain.length>1&&<div style={{textAlign:"center"}}><span style={{fontSize:12,color:C.fa,fontFamily:C.mn}}>{chain.map(n=>AE[n]).join(" → ")}</span></div>}
    </div>}
    <Inp label="FINAL OUTPUT LABEL (optional)" value={outL} onChange={setOutL} ph="e.g. Complete onboarding design with metrics"/>
    <div style={{display:"flex",gap:8}}>
      <button onClick={gen} disabled={!chain.length} style={{background:chain.length?`${C.cy}15`:"transparent",border:`1px solid ${chain.length?C.cy+"50":C.bdr}`,color:chain.length?C.cy:C.fa,borderRadius:8,padding:"10px 17px",fontSize:13,fontWeight:600,fontFamily:C.mn,cursor:chain.length?"pointer":"not-allowed",letterSpacing:"0.05em"}}>⚡ GENERATE PROMPT</button>
      {chain.length>0&&<button onClick={reset} style={{background:"transparent",border:`1px solid ${C.bdr}`,color:C.di,borderRadius:8,padding:"10px 14px",fontSize:12,fontFamily:C.mn,cursor:"pointer"}}>RESET</button>}
    </div>
    {res&&<div style={{marginTop:13}}><div style={{fontSize:10,color:C.gn,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>✓ PROMPT READY — saved to history</div><Code text={res} mh={280}/></div>}
  </Card>);
}

function LayerComposer(){
  const F=[
    {k:"role",       l:"ROLE",         p:"You are a senior full-stack developer and product designer."},
    {k:"context",    l:"CONTEXT",      p:"Product: [name]\nPlatform: mobile / web / hybrid\nAudience: [who uses this]"},
    {k:"objective",  l:"OBJECTIVE",    p:"[One clear sentence of success]\nSuccess criteria:\n- [criterion 1]"},
    {k:"constraints",l:"CONSTRAINTS",  p:"- Mobile-first\n- WCAG AA accessibility\n- 60fps animation budget"},
    {k:"aesthetic",  l:"AESTHETIC",    p:"- [visual style keyword]\n- [tone descriptor]"},
    {k:"planning",   l:"PLANNING",     p:"1. Define information architecture\n2. Define navigation model\n3. Validate accessibility"},
    {k:"output",     l:"OUTPUT FORMAT",p:"Generate:\n1. [file or artifact type]\n2. [second deliverable]"},
    {k:"refinement", l:"REFINEMENT",   p:"After generating:\n- Critique for clarity\n- Refine once for structure\n- Output final result only"},
  ];
  const[v,setV]=useState(Object.fromEntries(F.map(f=>[f.k,""])));
  const set=(k,val)=>setV(p=>({...p,[k]:val}));
  const built=F.filter(f=>v[f.k].trim()).map(f=>`${f.l}\n${v[f.k].trim()}`).join("\n\n");
  const filled=F.filter(f=>v[f.k].trim()).length;
  return(<Card sx={{marginBottom:14}}>
    <Lbl text="Fill in each layer → prompt assembles automatically" color={C.mg}/>
    <H3>8-Layer Prompt Composer</H3>
    <div style={{marginBottom:14}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
        <span style={{fontSize:11,color:C.di,fontFamily:C.mn}}>{filled}/{F.length} layers filled</span>
        {built&&<Cp text={built}/>}
      </div>
      <div style={{display:"flex",gap:4}}>{F.map(f=><div key={f.k} style={{flex:1,height:4,background:v[f.k].trim()?C.cy:C.bdr,borderRadius:2,transition:"background 0.2s"}}/>)}</div>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))",gap:11,marginBottom:14}}>
      {F.map(f=><div key={f.k}>
        <div style={{fontSize:10,color:v[f.k].trim()?C.cy:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:4,transition:"color 0.2s"}}>{f.l} {v[f.k].trim()?"✓":""}</div>
        <textarea value={v[f.k]} onChange={e=>set(f.k,e.target.value)} placeholder={f.p} rows={4} style={{width:"100%",boxSizing:"border-box",background:C.bg,border:`1px solid ${v[f.k].trim()?C.cy+"33":C.bdr}`,borderRadius:8,padding:"8px 11px",color:C.tx,fontSize:11,fontFamily:C.mn,outline:"none",resize:"vertical",lineHeight:1.6,transition:"border-color 0.2s"}}/>
      </div>)}
    </div>
    {built?<><div style={{fontSize:10,color:C.gn,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>✓ ASSEMBLED PROMPT</div><Code text={built} mh={260}/></>
    :<div style={{background:C.bg,border:`1px dashed ${C.bdr}`,borderRadius:10,padding:"16px",textAlign:"center"}}><div style={{fontSize:12,color:C.fa,fontFamily:C.mn}}>Fill in any layer above — prompt assembles in real time</div></div>}
  </Card>);
}

function WebAppGen(){
  const STACKS=["Next.js + Tailwind + Framer Motion","Next.js + Tailwind + GSAP","React + Vite + Framer Motion","SvelteKit + Tailwind","React Native + Expo","Nuxt + Tailwind"];
  const AEST=["dark-mode native","glassmorphism","neo-brutalism","neon accent","bento grid","kinetic typography","aurora gradients","minimal + editorial"];
  const[goal,setGoal]=useState("");
  const[aud,setAud]=useState(0);
  const[stk,setStk]=useState(0);
  const[ae,setAe]=useState([]);
  const[res,setRes]=useState("");
  const toggle=a=>setAe(p=>p.includes(a)?p.filter(x=>x!==a):[...p,a].slice(0,4));
  const gen=()=>{
    const p=`You are a senior full-stack developer and product designer.

ROLE: ${WEB_VARS[aud].label} perspective
GOAL: ${goal.trim()||"[Describe your app in one sentence]"}

FUNCTIONAL REQUIREMENTS
- Dynamic UI components
- Mobile-first responsive layout
- Interactive sections with user feedback
- Modular, reusable component architecture

UI/UX DESIGN LANGUAGE
${ae.length?ae.map(a=>`- ${a}`).join("\n"):"- Ultra-modern Gen-Z aesthetic\n- High-contrast typography\n- Smooth micro-interactions"}
- Dark/light adaptive themes

TECHNICAL STACK
- ${STACKS[stk]}
- Accessible semantic HTML · shadcn/ui components

OUTPUT FORMAT
Generate:
1. Project folder structure
2. Full source code (all files)
3. Instructions to run locally
4. Key component explanations

CONSTRAINTS
- Mobile-first always · WCAG AA accessibility minimum
- 60fps animation budget · No lorem ipsum · Avoid SaaS clichés

AESTHETIC LOCK
${ae.length?ae.join(" | "):"dark-mode native | neon-accent sparse | typography-first | hierarchy clear"}`;
    setRes(p);
  };
  return(<Card>
    <Lbl text="Configure your app → get a complete web app system prompt" color={C.mg}/>
    <H3>Web App Prompt Generator</H3>
    <Inp label="YOUR APP GOAL" value={goal} onChange={setGoal} ph="e.g. A dashboard for freelancers to track client projects and invoices"/>
    <div style={{marginBottom:12}}>
      <div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>AUDIENCE TYPE</div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{WEB_VARS.map((a,i)=><Pill key={a.id} label={a.label} active={aud===i} color={C.cy} onClick={()=>setAud(i)}/>)}</div>
      <div style={{fontSize:11,color:C.di,marginTop:6}}>{WEB_VARS[aud].desc}</div>
    </div>
    <div style={{marginBottom:12}}>
      <div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>TECH STACK</div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{STACKS.map((s,i)=><Pill key={i} label={s} active={stk===i} color={C.vi} onClick={()=>setStk(i)}/>)}</div>
    </div>
    <div style={{marginBottom:16}}>
      <div style={{fontSize:10,color:C.di,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>AESTHETIC KEYWORDS (pick up to 4)</div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{AEST.map(a=>{const s=ae.includes(a);return <button key={a} onClick={()=>toggle(a)} style={{background:s?`${C.mg}15`:"transparent",border:`1px solid ${s?C.mg+"55":C.bdr}`,color:s?C.mg:C.di,borderRadius:20,padding:"5px 12px",fontSize:11,fontFamily:C.mn,cursor:"pointer",transition:"all 0.15s"}}>{a}</button>;})}</div>
    </div>
    <button onClick={gen} style={{background:`${C.mg}15`,border:`1px solid ${C.mg}55`,color:C.mg,borderRadius:8,padding:"10px 18px",fontSize:13,fontWeight:600,fontFamily:C.mn,cursor:"pointer",letterSpacing:"0.05em",marginBottom:res?14:0}}>⚡ GENERATE WEB APP PROMPT</button>
    {res&&<><div style={{fontSize:10,color:C.gn,fontFamily:C.mn,letterSpacing:"0.1em",marginBottom:8}}>✓ PROMPT READY</div><Code text={res} mh={300}/></>}
  </Card>);
}

function PromptDiff(){
  const[a,setA]=useState("");
  const[b,setB]=useState("");
  const[res,setRes]=useState(null);
  const score=text=>{
    const t=text.toLowerCase();
    const r=x=>x.test(t)?1:0;
    const hasRole=r(/you are|act as|role:|you're a/);
    const hasCon=r(/wcag|mobile.first|60fps|accessibility|constraint/);
    const hasObj=r(/goal:|objective:|success|output|generate|create/);
    const hasOut=r(/output format|generate:|deliver|produce|format/);
    const hasRef=r(/refine|critique|review|revise|polish/);
    const hasPln=r(/step|plan|architect|structure|first/);
    const wc=text.trim().split(/\s+/).length;
    const vague=r(/nice|cool|awesome|modern|good design/)?-1:0;
    const cl=Math.min(10,Math.round((hasRole*2+hasObj*2+(vague===0?2:0)+(wc>30?2:1))*1.2+vague));
    const st=Math.min(10,Math.round((hasRole+hasCon+hasObj+hasOut+hasRef+hasPln)*1.5));
    const cn=Math.min(10,Math.round((hasCon*3+hasRef*2+hasPln*2+hasOut*2)*0.9));
    const pr=Math.min(10,Math.round((hasOut*3+hasRef*2+hasCon*2+hasPln*2)*0.85));
    const ov=((cl+st+cn+pr)/4).toFixed(1);
    const miss=[];
    if(!hasRole)miss.push("Role definition");
    if(!hasCon)miss.push("Constraints (mobile-first, WCAG)");
    if(!hasObj)miss.push("Clear objective");
    if(!hasOut)miss.push("Output format");
    if(!hasRef)miss.push("Refinement instruction");
    if(vague<0)miss.push("Remove vague words");
    return{cl,st,cn,pr,ov,miss};
  };
  const run=()=>{
    if(!a.trim()&&!b.trim())return;
    const sa=score(a),sb=score(b);
    const win=!a.trim()?"B":!b.trim()?"A":parseFloat(sa.ov)>=parseFloat(sb.ov)?"A":"B";
    setRes({a:sa,b:sb,win});
  };
  const Bar=({label,val,col})=><div style={{marginBottom:8}}><div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span style={{fontSize:11,color:C.mu}}>{label}</span><span style={{fontSize:11,fontFamily:C.mn,color:col}}>{val}/10</span></div><div style={{background:C.bg,borderRadius:999,height:5}}><div style={{width:`${val*10}%`,background:col,height:"100%",borderRadius:999,transition:"width 0.4s"}}/></div></div>;
  return(<Card>
    <Lbl text="Paste two prompts — get a side-by-side quality analysis" color={C.mg}/>
    <H3>Prompt Diff Tool</H3>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:14}}>
      <TA label="PROMPT A" value={a} onChange={setA} ph="Paste your first prompt here…" rows={6}/>
      <TA label="PROMPT B" value={b} onChange={setB} ph="Paste your second prompt here…" rows={6}/>
    </div>
    <button onClick={run} style={{background:`${C.mg}15`,border:`1px solid ${C.mg}55`,color:C.mg,borderRadius:8,padding:"10px 18px",fontSize:13,fontWeight:600,fontFamily:C.mn,cursor:"pointer",letterSpacing:"0.05em",marginBottom:14}}>⚡ ANALYZE PROMPTS</button>
    {res&&<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
      {[["A",res.a,C.cy],["B",res.b,C.vi]].filter(([lbl])=>(lbl==="A"?a.trim():b.trim())).map(([lbl,sc,col])=><div key={lbl} style={{background:C.bg,border:`2px solid ${res.win===lbl?col:C.bdr}`,borderRadius:10,padding:"14px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <div style={{fontWeight:700,color:col,fontFamily:C.mn,fontSize:16}}>PROMPT {lbl}</div>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            {res.win===lbl&&<span style={{fontSize:10,background:`${col}18`,color:col,border:`1px solid ${col}30`,borderRadius:20,padding:"2px 10px",fontFamily:C.mn}}>WINNER</span>}
            <span style={{fontSize:24,fontWeight:800,color:col,fontFamily:C.mn}}>{sc.ov}</span>
          </div>
        </div>
        <Bar label="Clarity" val={sc.cl} col={col}/>
        <Bar label="Structure" val={sc.st} col={col}/>
        <Bar label="Constraints" val={sc.cn} col={col}/>
        <Bar label="Predictability" val={sc.pr} col={col}/>
        {sc.miss.length>0&&<div style={{marginTop:10}}><div style={{fontSize:10,color:C.am,fontFamily:C.mn,marginBottom:6}}>MISSING</div>{sc.miss.map((m,i)=><div key={i} style={{fontSize:11,color:C.di,marginBottom:3}}>· {m}</div>)}</div>}
      </div>)}
    </div>}
  </Card>);
}

const BTOOLS=[{id:"workflow",label:"🦅 Workflow Builder"},{id:"composer",label:"🏗 8-Layer Composer"},{id:"webapp",label:"🌐 Web App Generator"},{id:"diff",label:"⚖️ Prompt Diff"}];
function Builder(){
  const[t,setT]=useState("workflow");
  const[bKey,setBKey]=useState(0);
  return(<div>
    <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:18,paddingBottom:14,borderBottom:`1px solid ${C.bdr}`}}>
      {BTOOLS.map(bt=><Pill key={bt.id} label={bt.label} active={t===bt.id} color={C.mg} onClick={()=>{setT(bt.id);setBKey(k=>k+1);}}/>)}
    </div>
    <div key={bKey} className="anim-slide">{t==="workflow"&&<WFBuilder/>}
    {t==="composer"&&<LayerComposer/>}
    {t==="webapp"&&<WebAppGen/>}
    {t==="diff"&&<PromptDiff/>}
  </div>);
}

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App(){
  const[zone,setZone]=useState("activate");
  const[zKey,setZKey]=useState(0);
  const[ripples,setRipples]=useState([]);
  const col=ZC[zone];

  const switchZone=(id,e)=>{
    if(id===zone)return;
    // Ripple effect on click
    const rect=e.currentTarget.getBoundingClientRect();
    const r={id:Date.now(),x:e.clientX-rect.left,y:e.clientY-rect.top,color:ZC[id]};
    setRipples(p=>[...p,r]);
    setTimeout(()=>setRipples(p=>p.filter(x=>x.id!==r.id)),600);
    setZone(id);
    setZKey(k=>k+1);
    // Smooth scroll to top on mobile
    if(window.scrollY>80)window.scrollTo({top:0,behavior:"smooth"});
  };

  return(<>
    <style>{FONT_CSS}</style>
    {/* SEO optimization */}
    <title>promptc OS — AI Prompt Engineering Reference v2026.3</title>
    <meta name="description" content="The complete reusable prompt library. 8-Layer Architecture, Animal Thinking Modes, 18 Workflows, Workflow Builder, Brand Systems, Design Vocab."/>
    <meta name="theme-color" content="#0B0D10"/>
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="dns-prefetch" href="https://fonts.googleapis.com"/>
    <div style={{minHeight:"100vh",background:C.bg,fontFamily:C.ss,color:C.tx,overscrollBehavior:"none"}}>
      {/* STICKY NAV */}
      <div style={{borderBottom:`1px solid ${C.bdr}`,padding:"clamp(10px,2vw,16px) clamp(12px,2.5vw,22px) 0",position:"sticky",top:0,background:C.bg+"f0",zIndex:100,backdropFilter:"blur(20px)",WebkitBackdropFilter:"blur(20px)"}}>
        <div style={{maxWidth:980,margin:"0 auto"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:4}}>
            <div style={{fontSize:"clamp(8px,1.2vw,10px)",fontFamily:C.mn,color:C.fa,letterSpacing:"0.15em"}}>promptc OS · v2026.3 · powerUP</div>
            <div style={{fontSize:"clamp(8px,1.2vw,10px)",fontFamily:C.mn,color:col,letterSpacing:"0.1em",animation:"glowPulse 2s ease infinite"}}>{ZONES.find(z=>z.id===zone)?.label}</div>
          </div>
          <h1 style={{margin:"0 0 12px",fontSize:"clamp(18px,3.5vw,28px)",fontWeight:900,letterSpacing:"0.03em",fontFamily:C.hd,lineHeight:1,transition:"color 0.4s"}}>
            AI PROMPT ENGINEERING <span style={{color:col,transition:"color 0.4s ease"}}>{ZONES.find(z=>z.id===zone)?.sub?.split(".")[0].toUpperCase()}</span>
          </h1>
          <div style={{display:"flex",gap:0,overflowX:"auto",scrollbarWidth:"none",WebkitOverflowScrolling:"touch"}}>
            {ZONES.map(z=>{const c=ZC[z.id];const a=zone===z.id;return(
              <button key={z.id} onClick={e=>switchZone(z.id,e)} style={{background:"transparent",border:"none",borderBottom:`2px solid ${a?c:"transparent"}`,color:a?c:C.di,padding:"8px clamp(8px,1.8vw,16px)",fontSize:"clamp(9px,1.4vw,12px)",fontWeight:600,cursor:"pointer",transition:"color 0.2s, border-color 0.2s",display:"flex",flexDirection:"column",alignItems:"flex-start",gap:1,whiteSpace:"nowrap",flexShrink:0,fontFamily:C.ss,position:"relative",overflow:"hidden"}}>
                {ripples.filter(r=>false).map(r=>( // zone-level ripple is on the outer button below
                  <span key={r.id} style={{position:"absolute",left:r.x,top:r.y,width:8,height:8,borderRadius:"50%",background:r.color,transform:"scale(0)",animation:"ripple 0.6s ease-out forwards",pointerEvents:"none",marginLeft:-4,marginTop:-4}}/>
                ))}
                <span>{z.label}</span>
                <span style={{fontSize:"clamp(7px,1vw,9px)",fontFamily:C.mn,color:a?c+"99":C.fa+"88",fontWeight:400,transition:"color 0.2s"}}>{z.sub}</span>
              </button>
            );})}
          </div>
        </div>
      </div>

      {/* ZONE CONTENT */}
      <div style={{maxWidth:980,margin:"0 auto",padding:"clamp(12px,2.5vw,20px) clamp(10px,2vw,22px) 80px"}}>
        <div key={zKey} className="anim-zone">
          {zone==="activate"&&<Activate/>}
          {zone==="build"   &&<Build/>}
          {zone==="validate"&&<Validate/>}
          {zone==="playbook"&&<Playbook/>}
          {zone==="builder" &&<Builder/>}
        </div>
      </div>

      {/* FLOATING ZONE INDICATOR — mobile */}
      <div style={{position:"fixed",bottom:16,left:"50%",transform:"translateX(-50%)",display:"flex",gap:6,padding:"6px 12px",background:C.sur+"ee",border:`1px solid ${col}33`,borderRadius:999,backdropFilter:"blur(12px)",zIndex:200,pointerEvents:"none"}}>
        {ZONES.map(z=><div key={z.id} style={{width:zone===z.id?20:6,height:6,borderRadius:999,background:zone===z.id?ZC[z.id]:C.bdr,transition:"all 0.3s cubic-bezier(0.16,1,0.3,1)"}}/>)}
      </div>
    </div>
  </>);
}

