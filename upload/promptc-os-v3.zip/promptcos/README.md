# promptc OS · v2026.3

> The complete reusable AI prompt library for practitioners.

[![Deploy with Vercel](https://img.shields.io/badge/Deploy-Vercel-black?logo=vercel)](https://vercel.com/new)

## Quick Start

```bash
git clone https://github.com/marktantongco/promptc.git
cd promptc && npm install && npm run dev
```

## Deploy to Vercel

```bash
npm install -g vercel && vercel
```

## Features

- **⚡ ACTIVATE** — Master prompt, Advocate mode, 6 task prompts, 6 templates
- **🏗 BUILD** — Animals+chains→prompt, 8-Layer snippets, Meta, Enhancement (with how-to), Web App generator (live prompt), JSON matrix→prompt, Typography, 6 Brand systems, Design Vocab (terms/misconceptions/combos)
- **✅ VALIDATE** — Lint rules, Quality checklist, Prompt scoring
- **📋 PLAYBOOK** — 18 searchable workflows
- **🔨 BUILDER** — Workflow Builder + history, 8-Layer Composer, Prompt Diff

## What's new in v2026.3

- Clipboard fix (works in sandboxed iframes)
- BUILD tab → neon orange accent
- Bebas Neue + DM Sans + DM Mono typography
- Fluid clamp() sizing — mobile + web responsive
- Zone enter animations + micro-interactions throughout
- Animal chain click → generates combined prompt
- 8-Layer click → copy-ready snippet per layer
- JSON matrix click → generates combined prompt
- Web App framework selector → live prompt updates
- Enhancement protocols now have "How to Use" view
- 6 brand systems: powerUP, SaaS, E-commerce, Fintech, Insurance, Creative Agency
- Design Vocab: Terms / Misconceptions / Combos views
- Floating dot indicator (mobile)
- SEO meta + performance optimizations

_promptc OS · powerUP · @markytanky_
